import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../config/api_config.dart';
import '../../services/property_service.dart';
import '../../models/property.dart';
import '../../widgets/property_card.dart';
import 'property_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  final String? initialTown;

  const SearchScreen({super.key, this.initialTown});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _selectedTown = 'Nairobi';
  String _selectedEstate = 'All';
  double _maxRent = 100000;
  String _propertyType = 'All';
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.initialTown != null) {
      _selectedTown = widget.initialTown!;
    }
  }

  @override
  Widget build(BuildContext context) {
    final estates = ['All', ...ApiConfig.townsAndEstates[_selectedTown] ?? []];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Makao'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by estate, apartment name...',
                prefixIcon: const Icon(Icons.search),
                fillColor: Colors.white,
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Filters
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Town Dropdown
                const Text('Town', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _selectedTown,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.location_city),
                  ),
                  items: ApiConfig.townsAndEstates.keys
                      .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedTown = value!;
                      _selectedEstate = 'All';
                    });
                  },
                ),
                const SizedBox(height: 12),

                // Estate Dropdown
                const Text('Estate', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _selectedEstate,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.location_on),
                  ),
                  items: estates
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (value) => setState(() => _selectedEstate = value!),
                ),
                const SizedBox(height: 12),

                // Rent Range Slider
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Max Rent',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                    Text(
                      'KES ${_maxRent.toStringAsFixed(0)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: MakaoTheme.primaryGreen,
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: _maxRent,
                  min: 3000,
                  max: 200000,
                  divisions: 39,
                  activeColor: MakaoTheme.primaryGreen,
                  onChanged: (value) => setState(() => _maxRent = value),
                ),
              ],
            ),
          ),

          // Results
          Expanded(
            child: FutureBuilder<List<Property>>(
              future: _fetchProperties(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off, size: 80, color: Colors.grey[300]),
                        const SizedBox(height: 16),
                        Text(
                          'No vacant properties found',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[500],
                          ),
                        ),
                        const Text(
                          'Try adjusting your filters',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  );
                }

                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.72,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    final property = snapshot.data![index];
                    return PropertyCard(
                      property: property,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              PropertyDetailScreen(property: property),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<List<Property>> _fetchProperties() async {
    // In production, this calls the API
    // For now, return mock data
    await Future.delayed(const Duration(seconds: 1));
    return [];
  }
}