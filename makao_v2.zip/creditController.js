const { lookupTenantCredit: lookupCredit } = require('../utils/creditCalculator');
const CreditScore = require('../models/CreditScore');

// @desc    Get own credit score (tenant)
exports.getMyCreditScore = async (req, res) => {
  try {
    const credit = await CreditScore.findOne({ tenantId: req.user._id });

    if (!credit) {
      return res.json({
        success: true,
        data: {
          score: 500,
          rating: 'Excellent',
          message: 'No payment history yet. Your score starts at 500!',
        },
      });
    }

    res.json({ success: true, data: credit });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// @desc    Lookup tenant credit (landlord/admin)
exports.lookupTenantCredit = async (req, res) => {
  try {
    const { nationalId, fullName, dateOfBirth } = req.body;

    if (!nationalId || !fullName || !dateOfBirth) {
      return res.status(400).json({
        success: false,
        message: 'National ID, Full Name, and Date of Birth are required',
      });
    }

    const credit = await lookupCredit(nationalId, fullName, dateOfBirth);

    if (!credit) {
      return res.json({
        success: true,
        data: null,
        message: 'No credit history found for this tenant',
      });
    }

    res.json({ success: true, data: credit });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};