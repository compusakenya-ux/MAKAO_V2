import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../config/api_config.dart';
import '../../services/property_service.dart';
import '../../services/credit_service.dart';
import '../../models/property.dart';
import '../../widgets/property_card.dart';
import '../../widgets/town_selector.dart';
import 'search_screen.dart';
import 'my_rentals_screen.dart';
import 'credit_score_screen.dart';
import 'payment_screen.dart';

class TenantHomeScreen extends StatefulWidget {
  const TenantHomeScreen({super.key});

  @override
  State<TenantHomeScreen> createState() => _TenantHomeScreenState();
}

class _TenantHomeScreenState extends State<TenantHomeScreen> {
  int _currentIndex = 0;
  String _selectedTown = 'Nairobi';
  String _selectedEstate = 'All';

  final List<Widget> _screens = [
    const _HomeTab(),
    const SearchScreen(),
    const MyRentalsScreen(),
    const CreditScoreScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.apartment),
            label: 'My Rentals',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.verified_user),
            label: 'Credit',
          ),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    final propertyService = Provider.of<PropertyService>(context);

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            expandedHeight: 120,
            floating: true,
            backgroundColor: MakaoTheme.primaryGreen,
            flexibleSpace: FlexibleSpaceBar(
              title: const Text('Makao'),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [MakaoTheme.primaryGreen, Color(0xFF004D2C)],
                  ),
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined),
                onPressed: () {},
              ),
            ],
          ),

          // Search Bar
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SearchScreen()),
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search, color: Colors.grey),
                      const SizedBox(width: 12),
                      Text(
                        'Search apartments in Kenya...',
                        style: TextStyle(color: Colors.grey[400]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Town Chips
          SliverToBoxAdapter(
            child: SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: ApiConfig.townsAndEstates.keys.map((town) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(town),
                      selected: false,
                      onSelected: (_) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SearchScreen(
                              initialTown: town,
                            ),
                          ),
                        );
                      },
                      selectedColor: MakaoTheme.primaryGreen,
                      labelStyle: const TextStyle(color: Colors.white),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // Featured Listings Header
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 24, 16, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '🔥 Featured Vacancies',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'See All',
                    style: TextStyle(
                      color: MakaoTheme.primaryGreen,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Property Grid
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.75,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  // Placeholder — will be replaced with real data
                  return PropertyCard(
                    property: Property(
                      id: '$index',
                      landlordId: 'l1',
                      title: 'Modern ${index + 1}BR Apartment',
                      description: 'Beautiful apartment',
                      town: 'Nairobi',
                      estate: 'Embakasi',
                      propertyType: 'Apartment',
                      bedrooms: index + 1,
                      bathrooms: 1,
                      rentAmount: 15000 + (index * 5000),
                      deposit: 15000,
                      amenities: ['WiFi', 'Parking', 'Water'],
                      images: [],
                      latitude: -1.286389,
                      longitude: 36.817223,
                      isVacant: true,
                      listedDate: DateTime.now(),
                    ),
                    onTap: () {},
                  );
                },
                childCount: 6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}