const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  initiateStkPush,
  mpesaCallback,
  queryStkStatus,
} = require('../controllers/mpesaController');

// Initiate payment (tenant)
router.post('/stk-push', protect, initiateStkPush);

// Safaricom callback (no auth — Safaricom calls this)
router.post('/callback', mpesaCallback);

// Query payment status
router.post('/query', protect, queryStkStatus);

module.exports = router;