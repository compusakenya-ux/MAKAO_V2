const axios = require('axios');
const mpesaConfig = require('../config/mpesa');
const Payment = require('../models/Payment');
const Wallet = require('../models/Wallet');
const Property = require('../models/Property');
const Lease = require('../models/Lease');
const { updateCreditScore } = require('../utils/creditCalculator');
const { sendWhatsAppReceipt } = require('../utils/whatsappUtils');
const { generateReceiptPDF } = require('../utils/receiptGenerator');

const COMMISSION_RATE = parseFloat(process.env.MAKAO_COMMISSION_RATE) || 0.02;

// @desc    Initiate M-Pesa STK Push (Lipa Na M-Pesa Online)
// @route   POST /v1/mpesa/stk-push
exports.initiateStkPush = async (req, res) => {
  try {
    const { phoneNumber, amount, propertyId, leaseId } = req.body;
    const tenantId = req.user._id;

    // Validate
    if (!phoneNumber || !amount || !propertyId) {
      return res.status(400).json({
        success: false,
        message: 'Phone number, amount, and property ID are required',
      });
    }

    // Format phone number to 254XXXXXXXXX
    let formattedPhone = phoneNumber.replace(/^0/, '254');
    if (!formattedPhone.startsWith('254')) {
      formattedPhone = `254${formattedPhone}`;
    }

    // Get property & landlord
    const property = await Property.findById(propertyId);
    if (!property) {
      return res.status(404).json({ success: false, message: 'Property not found' });
    }

    const landlordId = property.landlordId;

    // Calculate commission
    const totalAmount = parseFloat(amount);
    const makaoCommission = totalAmount * COMMISSION_RATE;
    const landlordReceivable = totalAmount - makaoCommission;

    // Get M-Pesa access token
    const accessToken = await mpesaConfig.getAccessToken();
    const timestamp = mpesaConfig.getTimestamp();
    const password = mpesaConfig.generatePassword(timestamp);

    // Create pending payment record
    const payment = await Payment.create({
      tenantId,
      landlordId,
      propertyId,
      leaseId,
      totalAmount,
      makaoCommission,
      landlordReceivable,
      mpesaPhoneNumber: formattedPhone,
      status: 'pending',
      paymentMonth: new Date().toLocaleString('default', { month: 'long' }),
      paymentYear: new Date().getFullYear(),
      dueDate: new Date(new Date().getFullYear(), new Date().getMonth(), 5),
    });

    // STK Push Request
    const stkResponse = await axios.post(
      `${mpesaConfig.baseUrl}/mpesa/stkpush/v1/processrequest`,
      {
        BusinessShortCode: mpesaConfig.shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: Math.round(totalAmount),
        PartyA: formattedPhone,
        PartyB: mpesaConfig.shortcode,
        PhoneNumber: formattedPhone,
        CallBackURL: mpesaConfig.callbackUrl,
        AccountReference: `Makao-${payment._id}`,
        TransactionDesc: `Rent Payment - ${property.title}`,
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );

    // Save checkout request ID
    payment.checkoutRequestId = stkResponse.data.CheckoutRequestID;
    await payment.save();

    res.status(200).json({
      success: true,
      message: 'STK Push sent successfully. Check your phone.',
      checkoutRequestId: stkResponse.data.CheckoutRequestID,
      merchantRequestId: stkResponse.data.MerchantRequestID,
      paymentId: payment._id,
    });
  } catch (error) {
    console.error('STK Push Error:', error.response?.data || error.message);
    res.status(500).json({
      success: false,
      message: 'Failed to initiate M-Pesa payment',
      error: error.response?.data || error.message,
    });
  }
};

// @desc    M-Pesa Callback (Safaricom sends payment result here)
// @route   POST /v1/mpesa/callback
exports.mpesaCallback = async (req, res) => {
  try {
    const callbackData = req.body.Body.stkCallback;
    const resultCode = callbackData.ResultCode;
    const resultDesc = callbackData.ResultDesc;
    const checkoutRequestId = callbackData.CheckoutRequestID;

    // Find the payment
    const payment = await Payment.findOne({ checkoutRequestId });
    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }

    if (resultCode === 0) {
      // ✅ Payment Successful
      const callbackMetadata = callbackData.CallbackMetadata.Item;

      const mpesaReceipt = callbackMetadata.find(
        (item) => item.Name === 'MpesaReceiptNumber'
      )?.Value;
      const transactionDate = callbackMetadata.find(
        (item) => item.Name === 'TransactionDate'
      )?.Value;
      const phoneNumber = callbackMetadata.find(
        (item) => item.Name === 'PhoneNumber'
      )?.Value;

      // Calculate days late
      const dueDate = new Date(payment.dueDate);
      const paidDate = new Date();
      const daysLate = Math.max(
        0,
        Math.floor((paidDate - dueDate) / (1000 * 60 * 60 * 24))
      );

      // Update payment
      payment.status = 'completed';
      payment.mpesaReceiptNumber = mpesaReceipt;
      payment.mpesaTransactionId = mpesaReceipt;
      payment.paidAt = paidDate;
      payment.daysLate = daysLate;
      await payment.save();

      // Credit landlord's wallet (minus 2% commission)
      let wallet = await Wallet.findOne({ userId: payment.landlordId });
      if (!wallet) {
        wallet = await Wallet.create({ userId: payment.landlordId });
      }

      wallet.balance += payment.landlordReceivable;
      wallet.totalEarned += payment.landlordReceivable;
      wallet.totalCommissionPaid += payment.makaoCommission;
      wallet.transactions.push({
        type: 'credit',
        amount: payment.landlordReceivable,
        description: `Rent from ${payment.tenantId} - ${payment.paymentMonth}`,
        reference: mpesaReceipt,
      });
      await wallet.save();

      // Update tenant's credit score
      await updateCreditScore(payment.tenantId, daysLate, payment);

      // Generate and send WhatsApp receipt
      try {
        const receiptUrl = await generateReceiptPDF(payment);
        await sendWhatsAppReceipt(
          payment.mpesaPhoneNumber || phoneNumber,
          payment,
          receiptUrl
        );
        payment.receiptSent = true;
        await payment.save();
      } catch (whatsappError) {
        console.error('WhatsApp receipt error:', whatsappError.message);
      }

      console.log(`✅ Payment completed: ${mpesaReceipt}`);
    } else {
      // ❌ Payment Failed
      payment.status = 'failed';
      await payment.save();
      console.log(`❌ Payment failed: ${resultDesc}`);
    }

    res.status(200).json({ message: 'Callback received' });
  } catch (error) {
    console.error('Callback Error:', error.message);
    res.status(500).json({ message: 'Callback processing error' });
  }
};

// @desc    Query STK Push Status
// @route   POST /v1/mpesa/query
exports.queryStkStatus = async (req, res) => {
  try {
    const { checkoutRequestId } = req.body;

    const accessToken = await mpesaConfig.getAccessToken();
    const timestamp = mpesaConfig.getTimestamp();
    const password = mpesaConfig.generatePassword(timestamp);

    const response = await axios.post(
      `${mpesaConfig.baseUrl}/mpesa/stkpushquery/v1/query`,
      {
        BusinessShortCode: mpesaConfig.shortcode,
        Password: password,
        Timestamp: timestamp,
        CheckoutRequestID: checkoutRequestId,
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    res.json({
      success: true,
      data: response.data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.response?.data || error.message,
    });
  }
};