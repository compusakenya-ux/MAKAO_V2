import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../models/property.dart';
import '../../services/payment_service.dart';
import '../../widgets/mpesa_payment_button.dart';

class PaymentScreen extends StatefulWidget {
  final Property property;
  final String leaseId;

  const PaymentScreen({
    super.key,
    required this.property,
    required this.leaseId,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _phoneController = TextEditingController();
  bool _isProcessing = false;
  String _statusMessage = '';

  @override
  void initState() {
    super.initState();
    // Pre-fill with registered phone
    _phoneController.text = '0712345678';
  }

  double get _rentAmount => widget.property.rentAmount;
  double get _makaoCommission => _rentAmount * 0.02; // 2%
  double get _totalPayable => _rentAmount; // Tenant pays full rent
  double get _landlordReceivable => _rentAmount - _makaoCommission;

  Future<void> _initiateMpesaPayment() async {
    if (_phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter your M-Pesa phone number')),
      );
      return;
    }

    setState(() {
      _isProcessing = true;
      _statusMessage = 'Sending STK Push to ${_phoneController.text}...';
    });

    try {
      final paymentService = Provider.of<PaymentService>(context, listen: false);
      final result = await paymentService.initiateMpesaPayment(
        phoneNumber: _phoneController.text,
        amount: _rentAmount.toInt(),
        propertyId: widget.property.id,
        leaseId: widget.leaseId,
      );

      if (result['success']) {
        setState(() {
          _statusMessage =
              '✅ STK Push sent! Check your phone and enter M-Pesa PIN.';
        });
        // Poll for payment confirmation
        _pollPaymentStatus(result['checkoutRequestId']);
      } else {
        setState(() {
          _statusMessage = '❌ Payment failed: ${result['message']}';
        });
      }
    } catch (e) {
      setState(() {
        _statusMessage = '❌ Error: ${e.toString()}';
      });
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Future<void> _pollPaymentStatus(String checkoutRequestId) async {
    // In production, poll the backend every 5 seconds
    // until payment is confirmed or times out
    await Future.delayed(const Duration(seconds: 30));
    if (mounted) {
      setState(() {
        _statusMessage = '⏳ Waiting for M-Pesa confirmation...';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pay Rent')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Property Info Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.property.title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${widget.property.estate}, ${widget.property.town}',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                    const Divider(height: 24),
                    _buildRow('Monthly Rent', 'KES ${_rentAmount.toStringAsFixed(0)}'),
                    _buildRow('Makao Fee (2%)',
                        'KES ${_makaoCommission.toStringAsFixed(0)} (deducted)'),
                    const Divider(),
                    _buildRow(
                      'You Pay',
                      'KES ${_totalPayable.toStringAsFixed(0)}',
                      isBold: true,
                      color: MakaoTheme.primaryGreen,
                    ),
                    _buildRow(
                      'Landlord Receives',
                      'KES ${_landlordReceivable.toStringAsFixed(0)}',
                      isSmall: true,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // M-Pesa Payment Section
            const Text(
              'Pay via M-Pesa',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              'An STK Push will be sent to your phone. Enter your M-Pesa PIN to complete.',
              style: TextStyle(color: Colors.grey[600], fontSize: 13),
            ),
            const SizedBox(height: 16),

            // Phone Number Input
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'M-Pesa Phone Number',
                prefixIcon: Icon(Icons.phone_android),
                prefixText: '+254 ',
                hintText: '712 345 678',
              ),
            ),
            const SizedBox(height: 24),

            // Status Message
            if (_statusMessage.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _statusMessage.contains('✅')
                      ? Colors.green[50]
                      : _statusMessage.contains('❌')
                          ? Colors.red[50]
                          : Colors.blue[50],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _statusMessage,
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
            const SizedBox(height: 24),

            // M-Pesa Pay Button
            MpesaPaymentButton(
              amount: _totalPayable,
              onPressed: _isProcessing ? null : _initiateMpesaPayment,
              isLoading: _isProcessing,
            ),

            const SizedBox(height: 16),
            Center(
              child: Text(
                '🔒 Secured by M-Pesa Daraja API',
                style: TextStyle(color: Colors.grey[500], fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(String label, String value,
      {bool isBold = false, bool isSmall = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: isSmall ? 12 : 14,
              color: isSmall ? Colors.grey : Colors.black87,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: isBold ? 20 : (isSmall ? 12 : 14),
              fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
              color: color ?? (isSmall ? Colors.grey : Colors.black87),
            ),
          ),
        ],
      ),
    );
  }
}