const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema(
  {
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    landlordId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    propertyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Property',
      required: true,
    },
    leaseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Lease',
    },
    totalAmount: {
      type: Number,
      required: true,
    },
    makaoCommission: {
      type: Number,
      required: true,
    },
    landlordReceivable: {
      type: Number,
      required: true,
    },
    mpesaTransactionId: {
      type: String,
      unique: true,
    },
    mpesaReceiptNumber: {
      type: String,
    },
    mpesaPhoneNumber: {
      type: String,
    },
    checkoutRequestId: {
      type: String,
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'cancelled'],
      default: 'pending',
    },
    paymentMonth: {
      type: String,
      required: true,
    },
    paymentYear: {
      type: Number,
      required: true,
    },
    dueDate: {
      type: Date,
      required: true,
    },
    paidAt: {
      type: Date,
    },
    daysLate: {
      type: Number,
      default: 0,
    },
    receiptSent: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

paymentSchema.index({ tenantId: 1, paymentMonth: 1, paymentYear: 1 });
paymentSchema.index({ landlordId: 1 });
paymentSchema.index({ status: 1 });

module.exports = mongoose.model('Payment', paymentSchema);