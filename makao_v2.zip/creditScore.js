const mongoose = require('mongoose');

const creditScoreSchema = new mongoose.Schema(
  {
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
    },
    nationalId: {
      type: String,
      required: true,
      unique: true,
    },
    fullName: {
      type: String,
      required: true,
    },
    dateOfBirth: {
      type: String,
      required: true,
    },
    score: {
      type: Number,
      default: 500,
      min: 100,
      max: 500,
    },
    totalPayments: {
      type: Number,
      default: 0,
    },
    onTimePayments: {
      type: Number,
      default: 0,
    },
    latePayments: {
      type: Number,
      default: 0,
    },
    totalDaysLate: {
      type: Number,
      default: 0,
    },
    rating: {
      type: String,
      enum: ['Excellent', 'Good', 'Fair', 'Poor', 'Critical'],
      default: 'Excellent',
    },
    history: [
      {
        month: String,
        year: Number,
        propertyId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Property',
        },
        rentAmount: Number,
        dueDate: Date,
        paidDate: Date,
        daysLate: { type: Number, default: 0 },
        pointsDeducted: { type: Number, default: 0 },
        status: {
          type: String,
          enum: ['On Time', 'Late', 'Unpaid'],
        },
      },
    ],
    lastUpdated: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

// Compound index for reference lookup
creditScoreSchema.index({ nationalId: 1, fullName: 1, dateOfBirth: 1 });

module.exports = mongoose.model('CreditScore', creditScoreSchema);