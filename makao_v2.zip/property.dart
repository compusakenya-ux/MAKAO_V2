class Property {
  final String id;
  final String landlordId;
  final String title;
  final String description;
  final String town;
  final String estate;
  final String propertyType; // Apartment, Bedsitter, 1BR, 2BR, 3BR, Maisonette, Bungalow
  final int bedrooms;
  final int bathrooms;
  final double rentAmount;
  final double deposit;
  final List<String> amenities;
  final List<String> images;
  final double latitude;
  final double longitude;
  final bool isVacant;
  final DateTime listedDate;

  Property({
    required this.id,
    required this.landlordId,
    required this.title,
    required this.description,
    required this.town,
    required this.estate,
    required this.propertyType,
    required this.bedrooms,
    required this.bathrooms,
    required this.rentAmount,
    required this.deposit,
    required this.amenities,
    required this.images,
    required this.latitude,
    required this.longitude,
    required this.isVacant,
    required this.listedDate,
  });

  factory Property.fromJson(Map<String, dynamic> json) {
    return Property(
      id: json['_id'] ?? '',
      landlordId: json['landlordId'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      town: json['town'] ?? '',
      estate: json['estate'] ?? '',
      propertyType: json['propertyType'] ?? '',
      bedrooms: json['bedrooms'] ?? 0,
      bathrooms: json['bathrooms'] ?? 0,
      rentAmount: (json['rentAmount'] ?? 0).toDouble(),
      deposit: (json['deposit'] ?? 0).toDouble(),
      amenities: List<String>.from(json['amenities'] ?? []),
      images: List<String>.from(json['images'] ?? []),
      latitude: (json['latitude'] ?? 0).toDouble(),
      longitude: (json['longitude'] ?? 0).toDouble(),
      isVacant: json['isVacant'] ?? true,
      listedDate: DateTime.parse(json['listedDate'] ?? DateTime.now().toString()),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'town': town,
      'estate': estate,
      'propertyType': propertyType,
      'bedrooms': bedrooms,
      'bathrooms': bathrooms,
      'rentAmount': rentAmount,
      'deposit': deposit,
      'amenities': amenities,
      'images': images,
      'latitude': latitude,
      'longitude': longitude,
      'isVacant': isVacant,
    };
  }
}