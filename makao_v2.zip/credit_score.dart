class CreditScore {
  final String tenantId;
  final String nationalId;
  final String fullName;
  final int score;          // 100 (worst) to 500 (best)
  final int totalPayments;
  final int onTimePayments;
  final int latePayments;
  final int totalDaysLate;
  final String rating;      // 'Excellent', 'Good', 'Fair', 'Poor', 'Critical'
  final List<CreditEvent> history;
  final DateTime lastUpdated;

  CreditScore({
    required this.tenantId,
    required this.nationalId,
    required this.fullName,
    required this.score,
    required this.totalPayments,
    required this.onTimePayments,
    required this.latePayments,
    required this.totalDaysLate,
    required this.rating,
    required this.history,
    required this.lastUpdated,
  });

  factory CreditScore.fromJson(Map<String, dynamic> json) {
    return CreditScore(
      tenantId: json['tenantId'] ?? '',
      nationalId: json['nationalId'] ?? '',
      fullName: json['fullName'] ?? '',
      score: json['score'] ?? 500,
      totalPayments: json['totalPayments'] ?? 0,
      onTimePayments: json['onTimePayments'] ?? 0,
      latePayments: json['latePayments'] ?? 0,
      totalDaysLate: json['totalDaysLate'] ?? 0,
      rating: json['rating'] ?? 'Excellent',
      history: (json['history'] as List?)
              ?.map((e) => CreditEvent.fromJson(e))
              .toList() ??
          [],
      lastUpdated: DateTime.parse(json['lastUpdated'] ?? DateTime.now().toString()),
    );
  }

  // Rating tiers
  static String getRating(int score) {
    if (score >= 450) return 'Excellent';
    if (score >= 350) return 'Good';
    if (score >= 250) return 'Fair';
    if (score >= 150) return 'Poor';
    return 'Critical';
  }

  static String getRatingColor(int score) {
    if (score >= 450) return '006B3F';  // Green
    if (score >= 350) return '2E8B57';  // Sea Green
    if (score >= 250) return 'BB8B2E';  // Gold
    if (score >= 150) return 'FF6B35';  // Orange
    return 'BB1E10';                     // Red
  }
}

class CreditEvent {
  final String month;
  final int year;
  final int daysLate;
  final int pointsDeducted;
  final String status;

  CreditEvent({
    required this.month,
    required this.year,
    required this.daysLate,
    required this.pointsDeducted,
    required this.status,
  });

  factory CreditEvent.fromJson(Map<String, dynamic> json) {
    return CreditEvent(
      month: json['month'] ?? '',
      year: json['year'] ?? 2026,
      daysLate: json['daysLate'] ?? 0,
      pointsDeducted: json['pointsDeducted'] ?? 0,
      status: json['status'] ?? '',
    );
  }
}