const twilio = require('twilio');

const client = twilio(
  process.env.WHATSAPP_ACCOUNT_SID,
  process.env.WHATSAPP_AUTH_TOKEN
);

/**
 * Send payment receipt via WhatsApp
 */
async function sendWhatsAppReceipt(phoneNumber, payment, receiptUrl) {
  try {
    // Format phone for WhatsApp
    let formattedPhone = phoneNumber.replace(/^0/, '254');
    if (!formattedPhone.startsWith('+')) {
      formattedPhone = `+${formattedPhone}`;
    }

    const message = `
🏠 *MAKAO RENT RECEIPT* 🏠
━━━━━━━━━━━━━━━━━━
📅 Date: ${new Date().toLocaleDateString('en-KE')}
🧾 Receipt #: ${payment.mpesaReceiptNumber}
💰 Amount Paid: KES ${payment.totalAmount.toLocaleString()}
📊 Makao Fee (2%): KES ${payment.makaoCommission.toLocaleString()}
🏦 Landlord Receives: KES ${payment.landlordReceivable.toLocaleString()}
📆 Month: ${payment.paymentMonth} ${payment.paymentYear}
✅ Status: PAID
━━━━━━━━━━━━━━━━━━
📱 M-Pesa Ref: ${payment.mpesaReceiptNumber}

${payment.daysLate > 0 ? `⚠️ Paid ${payment.daysLate} day(s) late` : '✅ Paid on time!'}

Thank you for using Makao! 🇰🇪
    `.trim();

    const result = await client.messages.create({
      from: process.env.WHATSAPP_FROM,
      to: `whatsapp:${formattedPhone}`,
      body: message,
      ...(receiptUrl && { mediaUrl: [receiptUrl] }),
    });

    console.log(`📱 WhatsApp receipt sent: ${result.sid}`);
    return result;
  } catch (error) {
    console.error('WhatsApp Error:', error.message);
    throw error;
  }
}

/**
 * Send rent reminder via WhatsApp
 */
async function sendRentReminder(phoneNumber, tenantName, amount, dueDate) {
  try {
    let formattedPhone = phoneNumber.replace(/^0/, '254');
    if (!formattedPhone.startsWith('+')) {
      formattedPhone = `+${formattedPhone}`;
    }

    const message = `
🔔 *MAKAO RENT REMINDER*

Hello ${tenantName},

Your rent of *KES ${amount.toLocaleString()}* is due on *${dueDate}*.

Pay via the Makao App to maintain your credit score! 📊

Late payments deduct 5 points per day from your 500-point score.

👉 Open Makao App to pay now.

— Makao Team 🏠🇰🇪
    `.trim();

    await client.messages.create({
      from: process.env.WHATSAPP_FROM,
      to: `whatsapp:${formattedPhone}`,
      body: message,
    });
  } catch (error) {
    console.error('Reminder Error:', error.message);
  }
}

module.exports = { sendWhatsAppReceipt, sendRentReminder };