class Tenant {
  final String id;
  final String fullName;
  final String nationalId;
  final String dateOfBirth;
  final String phoneNumber;
  final String email;
  final String profileImage;
  final String role; // 'tenant', 'landlord', 'admin'
  final DateTime createdAt;

  Tenant({
    required this.id,
    required this.fullName,
    required this.nationalId,
    required this.dateOfBirth,
    required this.phoneNumber,
    required this.email,
    this.profileImage = '',
    this.role = 'tenant',
    required this.createdAt,
  });

  factory Tenant.fromJson(Map<String, dynamic> json) {
    return Tenant(
      id: json['_id'] ?? '',
      fullName: json['fullName'] ?? '',
      nationalId: json['nationalId'] ?? '',
      dateOfBirth: json['dateOfBirth'] ?? '',
      phoneNumber: json['phoneNumber'] ?? '',
      email: json['email'] ?? '',
      profileImage: json['profileImage'] ?? '',
      role: json['role'] ?? 'tenant',
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
    );
  }
}