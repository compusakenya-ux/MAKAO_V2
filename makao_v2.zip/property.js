const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema(
  {
    landlordId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
    },
    town: {
      type: String,
      required: true,
      enum: ['Nairobi', 'Mombasa', 'Nakuru', 'Kisumu', 'Eldoret', 'Kisii'],
    },
    estate: {
      type: String,
      required: true,
    },
    propertyType: {
      type: String,
      required: true,
      enum: [
        'Bedsitter',
        '1 Bedroom',
        '2 Bedroom',
        '3 Bedroom',
        'Apartment',
        'Maisonette',
        'Bungalow',
        'Studio',
      ],
    },
    bedrooms: { type: Number, default: 1 },
    bathrooms: { type: Number, default: 1 },
    rentAmount: {
      type: Number,
      required: true,
      min: 1000,
    },
    deposit: {
      type: Number,
      default: 0,
    },
    amenities: [String],
    images: [String],
    location: {
      latitude: Number,
      longitude: Number,
    },
    isVacant: {
      type: Boolean,
      default: true,
    },
    currentTenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    listedDate: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

// Indexes for fast search
propertySchema.index({ town: 1, estate: 1 });
propertySchema.index({ isVacant: 1 });
propertySchema.index({ rentAmount: 1 });
propertySchema.index({ propertyType: 1 });

module.exports = mongoose.model('Property', propertySchema);