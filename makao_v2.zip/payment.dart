class Payment {
  final String id;
  final String tenantId;
  final String landlordId;
  final String propertyId;
  final double totalAmount;
  final double makaoCommission; // 2%
  final double landlordReceivable; // 98%
  final String mpesaTransactionId;
  final String mpesaReceiptNumber;
  final String status; // 'pending', 'completed', 'failed'
  final String paymentMonth;
  final int paymentYear;
  final DateTime paidAt;
  final DateTime dueDate;
  final int daysLate;

  Payment({
    required this.id,
    required this.tenantId,
    required this.landlordId,
    required this.propertyId,
    required this.totalAmount,
    required this.makaoCommission,
    required this.landlordReceivable,
    required this.mpesaTransactionId,
    required this.mpesaReceiptNumber,
    required this.status,
    required this.paymentMonth,
    required this.paymentYear,
    required this.paidAt,
    required this.dueDate,
    required this.daysLate,
  });

  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      id: json['_id'] ?? '',
      tenantId: json['tenantId'] ?? '',
      landlordId: json['landlordId'] ?? '',
      propertyId: json['propertyId'] ?? '',
      totalAmount: (json['totalAmount'] ?? 0).toDouble(),
      makaoCommission: (json['makaoCommission'] ?? 0).toDouble(),
      landlordReceivable: (json['landlordReceivable'] ?? 0).toDouble(),
      mpesaTransactionId: json['mpesaTransactionId'] ?? '',
      mpesaReceiptNumber: json['mpesaReceiptNumber'] ?? '',
      status: json['status'] ?? 'pending',
      paymentMonth: json['paymentMonth'] ?? '',
      paymentYear: json['paymentYear'] ?? 2026,
      paidAt: DateTime.parse(json['paidAt'] ?? DateTime.now().toString()),
      dueDate: DateTime.parse(json['dueDate'] ?? DateTime.now().toString()),
      daysLate: json['daysLate'] ?? 0,
    );
  }
}