import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../models/credit_score.dart';

class TenantReferenceScreen extends StatefulWidget {
  const TenantReferenceScreen({super.key});

  @override
  State<TenantReferenceScreen> createState() => _TenantReferenceScreenState();
}

class _TenantReferenceScreenState extends State<TenantReferenceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _idController = TextEditingController();
  final _nameController = TextEditingController();
  final _dobController = TextEditingController();
  bool _isSearching = false;
  CreditScore? _result;

  Future<void> _lookupTenant() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSearching = true);

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isSearching = false;
      _result = CreditScore(
        tenantId: 't123',
        nationalId: _idController.text,
        fullName: _nameController.text,
        score: 420,
        totalPayments: 18,
        onTimePayments: 15,
        latePayments: 3,
        totalDaysLate: 12,
        rating: CreditScore.getRating(420),
        history: [
          CreditEvent(
            month: 'June',
            year: 2026,
            daysLate: 0,
            pointsDeducted: 0,
            status: 'On Time',
          ),
          CreditEvent(
            month: 'May',
            year: 2026,
            daysLate: 3,
            pointsDeducted: 15,
            status: 'Late',
          ),
        ],
        lastUpdated: DateTime.now(),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tenant Reference Check')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '🔍 Lookup Tenant Credit History',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              'Enter the prospective tenant\'s details to pull their Makao payment reference score.',
              style: TextStyle(color: Colors.grey[600]),
            ),
            const SizedBox(height: 24),

            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _idController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'National ID Number *',
                      prefixIcon: Icon(Icons.badge),
                      hintText: 'e.g., 12345678',
                    ),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Full Names *',
                      prefixIcon: Icon(Icons.person),
                      hintText: 'e.g., John Mwangi Kamau',
                    ),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _dobController,
                    decoration: const InputDecoration(
                      labelText: 'Date of Birth *',
                      prefixIcon: Icon(Icons.calendar_today),
                      hintText: 'DD/MM/YYYY',
                    ),
                    onTap: () async {
                      final date = await showDatePicker(
                        context: context,
                        initialDate: DateTime(1995),
                        firstDate: DateTime(1950),
                        lastDate: DateTime(2010),
                      );
                      if (date != null) {
                        _dobController.text =
                            '${date.day}/${date.month}/${date.year}';
                      }
                    },
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isSearching ? null : _lookupTenant,
                      child: _isSearching
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text('PULL TENANT REFERENCE'),
                    ),
                  ),
                ],
              ),
            ),

            // Results
            if (_result != null) ...[
              const SizedBox(height: 32),
              const Divider(),
              const SizedBox(height: 16),
              const Text(
                '📋 Tenant Reference Report',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 16),

              // Score Display
              Card(
                color: Color(
                  int.parse('FF${CreditScore.getRatingColor(_result!.score)}',
                      radix: 16),
                ).withOpacity(0.1),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 35,
                        backgroundColor: Color(
                          int.parse(
                              'FF${CreditScore.getRatingColor(_result!.score)}',
                              radix: 16),
                        ),
                        child: Text(
                          '${_result!.score}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _result!.fullName,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text('ID: ${_result!.nationalId}'),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Color(
                                  int.parse(
                                      'FF${CreditScore.getRatingColor(_result!.score)}',
                                      radix: 16),
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                _result!.rating,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Payment History
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Payment History',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text('Total Payments: ${_result!.totalPayments}'),
                      Text('On Time: ${_result!.onTimePayments} ✅'),
                      Text('Late: ${_result!.latePayments} ⚠️'),
                      Text('Total Days Late: ${_result!.totalDaysLate}'),
                      const Divider(height: 24),
                      const Text(
                        'Recent Activity:',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      ..._result!.history.map((event) => ListTile(
                            dense: true,
                            leading: Icon(
                              event.daysLate == 0
                                  ? Icons.check_circle
                                  : Icons.warning,
                              color: event.daysLate == 0
                                  ? Colors.green
                                  : Colors.orange,
                              size: 20,
                            ),
                            title: Text('${event.month} ${event.year}'),
                            subtitle: Text(
                              event.daysLate == 0
                                  ? 'Paid on time'
                                  : '${event.daysLate} days late (-${event.pointsDeducted} pts)',
                            ),
                          )),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}