const CreditScore = require('../models/CreditScore');
const Payment = require('../models/Payment');
const User = require('../models/User');

const MAX_SCORE = 500;
const MIN_SCORE = 100;
const POINTS_PER_DAY_LATE = 5;

/**
 * Update a tenant's credit score after a payment
 * Starting score: 500 (best)
 * Deduction: 5 points per day late after the monthly deadline
 * Floor: 100 (worst)
 */
async function updateCreditScore(tenantId, daysLate, payment) {
  try {
    const user = await User.findById(tenantId);
    if (!user) return;

    let credit = await CreditScore.findOne({ tenantId });

    if (!credit) {
      // First-time tenant — start at 500
      credit = await CreditScore.create({
        tenantId,
        nationalId: user.nationalId,
        fullName: user.fullName,
        dateOfBirth: user.dateOfBirth,
        score: MAX_SCORE,
        totalPayments: 0,
        onTimePayments: 0,
        latePayments: 0,
        totalDaysLate: 0,
        rating: 'Excellent',
        history: [],
      });
    }

    // Calculate points deducted
    const pointsDeducted = daysLate * POINTS_PER_DAY_LATE;

    // Update score
    credit.totalPayments += 1;
    credit.totalDaysLate += daysLate;

    if (daysLate === 0) {
      credit.onTimePayments += 1;
    } else {
      credit.latePayments += 1;
      credit.score = Math.max(MIN_SCORE, credit.score - pointsDeducted);
    }

    // Add to history
    credit.history.push({
      month: payment.paymentMonth,
      year: payment.paymentYear,
      propertyId: payment.propertyId,
      rentAmount: payment.totalAmount,
      dueDate: payment.dueDate,
      paidDate: payment.paidAt,
      daysLate,
      pointsDeducted,
      status: daysLate === 0 ? 'On Time' : 'Late',
    });

    // Keep only last 24 months of history
    if (credit.history.length > 24) {
      credit.history = credit.history.slice(-24);
    }

    // Update rating
    credit.rating = getRating(credit.score);
    credit.lastUpdated = new Date();

    await credit.save();

    console.log(
      `📊 Credit updated for ${user.fullName}: ${credit.score} (${credit.rating})`
    );

    return credit;
  } catch (error) {
    console.error('Credit Score Update Error:', error.message);
    throw error;
  }
}

/**
 * Get rating label from score
 */
function getRating(score) {
  if (score >= 450) return 'Excellent';
  if (score >= 350) return 'Good';
  if (score >= 250) return 'Fair';
  if (score >= 150) return 'Poor';
  return 'Critical';
}

/**
 * Lookup tenant credit by ID, Name, DOB (for landlords)
 */
async function lookupTenantCredit(nationalId, fullName, dateOfBirth) {
  try {
    const credit = await CreditScore.findOne({
      nationalId,
      fullName: { $regex: new RegExp(fullName, 'i') },
      dateOfBirth,
    }).select('-__v');

    if (!credit) {
      return null;
    }

    return credit;
  } catch (error) {
    console.error('Credit Lookup Error:', error.message);
    throw error;
  }
}

/**
 * Batch update all credit scores (cron job)
 * Marks unpaid months and deducts points
 */
async function updateAllCreditScores() {
  try {
    const activeLeases = await require('../models/Lease').find({
      status: 'active',
    });

    const currentDate = new Date();
    const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
    const currentYear = currentDate.getFullYear();

    for (const lease of activeLeases) {
      // Check if rent was paid this month
      const payment = await Payment.findOne({
        tenantId: lease.tenantId,
        propertyId: lease.propertyId,
        paymentMonth: currentMonth,
        paymentYear: currentYear,
        status: 'completed',
      });

      if (!payment) {
        // Calculate days since due date
        const dueDate = new Date(
          currentYear,
          currentDate.getMonth(),
          lease.dueDayOfMonth
        );

        if (currentDate > dueDate) {
          const daysLate = Math.floor(
            (currentDate - dueDate) / (1000 * 60 * 60 * 24)
          );

          // Create unpaid record and deduct points
          const unpaidPayment = await Payment.create({
            tenantId: lease.tenantId,
            landlordId: lease.landlordId,
            propertyId: lease.propertyId,
            leaseId: lease._id,
            totalAmount: lease.monthlyRent,
            makaoCommission: lease.monthlyRent * 0.02,
            landlordReceivable: lease.monthlyRent * 0.98,
            status: 'failed',
            paymentMonth: currentMonth,
            paymentYear: currentYear,
            dueDate,
            daysLate,
          });

          await updateCreditScore(lease.tenantId, daysLate, unpaidPayment);
        }
      }
    }

    console.log('✅ Batch credit score update completed');
  } catch (error) {
    console.error('Batch Credit Update Error:', error.message);
  }
}

module.exports = {
  updateCreditScore,
  getRating,
  lookupTenantCredit,
  updateAllCreditScores,
};