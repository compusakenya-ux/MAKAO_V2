const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

async function generateReceiptPDF(payment) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: 'A6', margin: 30 });
      const fileName = `receipt_${payment.mpesaReceiptNumber || payment._id}.pdf`;
      const filePath = path.join(__dirname, '../receipts', fileName);

      // Ensure directory exists
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      const stream = fs.createWriteStream(filePath);
      doc.pipe(stream);

      // Header
      doc
        .fontSize(20)
        .fillColor('#006B3F')
        .text('MAKAO', { align: 'center' })
        .fontSize(10)
        .fillColor('#666')
        .text('Kenya Rental Platform', { align: 'center' })
        .moveDown();

      doc
        .fontSize(14)
        .fillColor('#333')
        .text('PAYMENT RECEIPT', { align: 'center' })
        .moveDown();

      // Details
      doc.fontSize(10).fillColor('#333');
      doc.text(`Receipt #: ${payment.mpesaReceiptNumber || 'N/A'}`);
      doc.text(`Date: ${new Date().toLocaleDateString('en-KE')}`);
      doc.text(`Month: ${payment.paymentMonth} ${payment.paymentYear}`);
      doc.moveDown();

      doc.text(`Total Paid: KES ${payment.totalAmount.toLocaleString()}`);
      doc.text(`Makao Fee (2%): KES ${payment.makaoCommission.toLocaleString()}`);
      doc.text(
        `Landlord Receives: KES ${payment.landlordReceivable.toLocaleString()}`
      );
      doc.moveDown();

      doc.text(`M-Pesa Ref: ${payment.mpesaReceiptNumber || 'N/A'}`);
      doc.text(`Status: ${payment.status.toUpperCase()}`);

      if (payment.daysLate > 0) {
        doc.fillColor('#BB1E10').text(`⚠ Late by ${payment.daysLate} day(s)`);
      } else {
        doc.fillColor('#006B3F').text('✅ Paid on time');
      }

      doc.end();

      stream.on('finish', () => {
        // In production, upload to Cloudinary/S3 and return URL
        resolve(`https://api.makao.co.ke/receipts/${fileName}`);
      });
    } catch (error) {
      reject(error);
    }
  });
}

module.exports = { generateReceiptPDF };