import React, { useState } from 'react';
import { CreditScore, User } from '../types';
import { CreditScoreCard } from '../components/CreditScoreCard';
import { Search, SearchCheck, Info } from 'lucide-react';

interface CreditScoreCheckerViewProps {
  creditScore: CreditScore;
  tenant: User;
  onOpenCertificate: () => void;
}

export const CreditScoreCheckerView: React.FC<CreditScoreCheckerViewProps> = ({
  creditScore,
  tenant,
  onOpenCertificate,
}) => {
  const [lookupNationalId, setLookupNationalId] = useState('');
  const [searchedScore, setSearchedScore] = useState<CreditScore | null>(null);
  const [searchedErr, setSearchedErr] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (lookupNationalId === tenant.nationalId || lookupNationalId === '12345678') {
      setSearchedScore(creditScore);
      setSearchedErr('');
    } else {
      setSearchedErr('National ID not found in Makao Rent Credit Bureau database.');
      setSearchedScore(null);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Landlord & Agent Credit Checker Tool Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-slate-950 border border-cyan-500/40 text-cyan-400 flex items-center justify-center font-extrabold text-lg shadow-[0_0_10px_rgba(6,182,212,0.2)]">
            C
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white">National Rent Credit Score Lookup</h1>
            <p className="text-xs text-slate-400">Kenyan Landlords & Property Managers Tenant Verification Tool</p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              required
              placeholder="Enter Tenant Kenyan National ID (Try '12345678')..."
              value={lookupNationalId}
              onChange={(e) => setLookupNationalId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500/50 font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-6 py-2.5 bg-slate-950 hover:bg-slate-800 text-cyan-300 border border-cyan-500/40 font-bold rounded-xl text-xs shadow-[0_0_12px_rgba(6,182,212,0.2)] transition-all shrink-0 flex items-center justify-center gap-2"
          >
            <SearchCheck className="w-4 h-4 text-cyan-400" />
            <span>Verify Tenant Credit Score</span>
          </button>
        </form>

        {searchedErr && (
          <p className="text-xs text-rose-300 bg-rose-950/80 p-3 rounded-xl border border-rose-800 font-medium">
            {searchedErr}
          </p>
        )}
      </div>

      {/* Primary Credit Score Card */}
      <CreditScoreCard creditScore={searchedScore || creditScore} onOpenCertificate={onOpenCertificate} />

      {/* Credit Scoring Algorithm Rules Explanation */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
        <h3 className="font-extrabold text-white text-base flex items-center gap-2">
          <Info className="w-5 h-5 text-cyan-400" />
          How the Kenyan Rent Credit Scoring Algorithm Works
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-cyan-400 text-sm block">+10 Points On-Time Bonus</span>
            <p className="text-slate-300 leading-relaxed">
              Paying rent on or before the due date (5th of every month) via M-Pesa Express STK Push adds +10 points to your score.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-amber-400 text-sm block">-5 Points / Day Late Penalty</span>
            <p className="text-slate-300 leading-relaxed">
              Delaying rent payment past the grace period deducts -5 points per day late, encouraging timely rent discipline.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-sky-400 text-sm block">Landlord Verification Certificate</span>
            <p className="text-slate-300 leading-relaxed">
              Generates an official tamper-proof reference certificate that you can present to new landlords to skip high security deposits!
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
