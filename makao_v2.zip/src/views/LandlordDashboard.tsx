import React, { useState } from 'react';
import { User, Property, Lease, Payment, LeaseApplication } from '../types';
import { Building2, Plus, CheckCircle2, Clock, MessageSquare, FileText, UserCheck } from 'lucide-react';

interface LandlordDashboardProps {
  landlord: User;
  properties: Property[];
  leases: Lease[];
  payments: Payment[];
  leaseApplications: LeaseApplication[];
  onOpenAddProperty: () => void;
  onSendWhatsappReminder: (tenantPhone: string, tenantName: string, amount: number, unit: string) => void;
}

export const LandlordDashboard: React.FC<LandlordDashboardProps> = ({
  landlord,
  properties,
  leases,
  payments,
  leaseApplications,
  onOpenAddProperty,
  onSendWhatsappReminder,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'applications' | 'properties'>('overview');

  const myProperties = properties.filter((p) => p.landlordId === landlord.id || landlord.role === 'landlord');
  const totalUnitsCount = myProperties.reduce((acc, p) => acc + p.totalUnits, 0);
  const vacantUnitsCount = myProperties.reduce((acc, p) => acc + p.availableUnits, 0);
  const totalRentCollectedThisMonth = payments.reduce((acc, p) => acc + p.amount, 0);

  return (
    <div className="space-y-6">
      
      {/* Landlord Header Banner */}
      <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold text-cyan-800 uppercase tracking-widest bg-cyan-50 px-2.5 py-1 rounded-md border border-cyan-200">
            LANDLORD & PROPERTY MANAGER HUB
          </span>
          <h1 className="text-2xl font-black mt-2 text-slate-900">{landlord.name}</h1>
          <p className="text-xs text-slate-600 mt-1">
            Automated M-Pesa Paybill Collection Gateway &bull; Paybill 889900
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAddProperty}
            className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl text-xs shadow-sm transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>Add New Property</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Rent Collections</p>
          <p className="text-2xl font-black text-cyan-700">KSh {totalRentCollectedThisMonth.toLocaleString()}</p>
          <p className="text-[10px] text-cyan-800 font-extrabold flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-cyan-600" /> M-Pesa Auto-settled
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Total Managed Properties</p>
          <p className="text-2xl font-black text-slate-900">{myProperties.length} Buildings</p>
          <p className="text-[10px] text-slate-500 font-medium">{totalUnitsCount} Total Apartment Units</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Occupancy Rate</p>
          <p className="text-2xl font-black text-slate-900">
            {totalUnitsCount > 0 ? (((totalUnitsCount - vacantUnitsCount) / totalUnitsCount) * 100).toFixed(0) : 100}%
          </p>
          <p className="text-[10px] text-slate-500 font-medium">{vacantUnitsCount} Vacant Units for Rent</p>
        </div>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-2 text-xs font-bold">
        <button
          onClick={() => setActiveSubTab('overview')}
          className={`pb-3 px-4 transition-colors ${
            activeSubTab === 'overview'
              ? 'text-cyan-700 border-b-2 border-cyan-600'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Tenant Payments & Reminders
        </button>
        <button
          onClick={() => setActiveSubTab('applications')}
          className={`pb-3 px-4 transition-colors relative ${
            activeSubTab === 'applications'
              ? 'text-cyan-700 border-b-2 border-cyan-600'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Tenant Lease Applications ({leaseApplications.length})
        </button>
        <button
          onClick={() => setActiveSubTab('properties')}
          className={`pb-3 px-4 transition-colors ${
            activeSubTab === 'properties'
              ? 'text-cyan-700 border-b-2 border-cyan-600'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          My Properties ({myProperties.length})
        </button>
      </div>

      {/* View Content */}
      {activeSubTab === 'overview' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-900 text-base">Active Leases & Rent Payment Tracking</h3>
            <span className="text-xs text-slate-500 font-medium">Automated WhatsApp & SMS Notifications</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                  <th className="p-3">Tenant & Unit</th>
                  <th className="p-3">Property</th>
                  <th className="p-3">Rent Amount</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {leases.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3 font-extrabold text-slate-900">
                      John Kamau
                      <span className="block text-[11px] text-slate-500 font-mono">Unit {l.unitNumber}</span>
                    </td>
                    <td className="p-3 font-medium">{l.propertyTitle}</td>
                    <td className="p-3 font-extrabold text-cyan-700">KSh {l.rentAmount.toLocaleString()}</td>
                    <td className="p-3">
                      <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold px-2.5 py-1 rounded-full">
                        <Clock className="w-3 h-3 text-amber-600" /> Due on 5th
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => onSendWhatsappReminder('+254712345678', 'John Kamau', l.rentAmount, l.unitNumber)}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-bold transition-all shadow-xs inline-flex items-center gap-1"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-cyan-600" />
                        <span>Send WhatsApp Rent Reminder</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tenant Lease Applications Subtab */}
      {activeSubTab === 'applications' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <FileText className="w-5 h-5 text-cyan-600" />
              Tenant Lease Applications ({leaseApplications.length})
            </h3>
            <span className="text-xs text-slate-500 font-medium">Submitted via Property View Link</span>
          </div>

          {leaseApplications.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {leaseApplications.map((app) => (
                <div key={app.id} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                  <div className="flex justify-between items-start border-b border-slate-200 pb-2">
                    <div>
                      <span className="text-[10px] font-extrabold text-cyan-800 uppercase bg-cyan-100 px-2 py-0.5 rounded border border-cyan-200">
                        {app.unitNumber} &bull; {app.appliedDate}
                      </span>
                      <h4 className="font-extrabold text-slate-900 text-sm mt-1">{app.fullName}</h4>
                    </div>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-200">
                      {app.status}
                    </span>
                  </div>

                  <p className="text-xs font-bold text-slate-800">{app.propertyTitle}</p>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">National ID</span>
                      <span className="font-mono font-bold text-slate-900">{app.nationalId}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Applicant Email</span>
                      <span className="font-medium text-slate-900 truncate block">{app.email || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Applicant Phone</span>
                      <span className="font-mono font-bold text-slate-900">{app.phone}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Emergency Contact Name</span>
                      <span className="font-medium text-slate-900">{app.emergencyContactName}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Emergency Contact Tel</span>
                      <span className="font-mono font-bold text-slate-900">{app.emergencyContactPhone}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Income Source</span>
                      <span className="font-bold text-cyan-700">{app.sourceOfIncome}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Employer / Institution</span>
                      <span className="font-medium text-slate-900">{app.employerName} ({app.employerContactPhone})</span>
                    </div>
                  </div>

                  {/* Evidence Documents Section */}
                  {app.documents && app.documents.length > 0 && (
                    <div className="pt-2 border-t border-slate-200">
                      <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                        Attached Evidence Files ({app.documents.length})
                      </span>
                      <div className="grid grid-cols-1 gap-1.5">
                        {app.documents.map((doc, docIdx) => (
                          <div key={docIdx} className="bg-white border border-slate-200 p-2 rounded-lg flex items-center justify-between text-xs">
                            <div className="flex items-center space-x-2">
                              <FileText className="w-4 h-4 text-cyan-600 shrink-0" />
                              <div>
                                <span className="font-bold text-slate-900 text-[11px] block">{doc.docType}</span>
                                <span className="text-[10px] text-slate-500 font-mono">{doc.fileName}</span>
                              </div>
                            </div>
                            <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded border border-emerald-200">
                              Verified
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="pt-2 flex justify-end gap-2 border-t border-slate-200">
                    <a
                      href={`https://wa.me/${app.phone.replace(/\+/g, '')}?text=Hello%20${encodeURIComponent(app.fullName)},%20I%20received%20your%20lease%20application%20for%20${encodeURIComponent(app.propertyTitle)}.`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-700 text-white rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Contact Applicant</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-500 space-y-1">
              <UserCheck className="w-8 h-8 text-slate-400 mx-auto" />
              <p>No tenant lease applications submitted yet.</p>
            </div>
          )}
        </div>
      )}

      {activeSubTab === 'properties' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {myProperties.map((p) => (
            <div key={p.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
              <img src={p.imageUrls[0]} alt={p.title} className="w-full h-40 object-cover rounded-xl border border-slate-200" />
              <div>
                <span className="text-[10px] font-bold text-cyan-800 bg-cyan-50 px-2 py-0.5 rounded uppercase border border-cyan-200">
                  {p.city} &bull; {p.type}
                </span>
                <h3 className="font-black text-slate-900 text-base mt-2">{p.title}</h3>
                <p className="text-xs text-slate-500">{p.location}</p>
              </div>

              <div className="flex justify-between items-baseline pt-2 border-t border-slate-100 text-xs">
                <span className="text-slate-500">Rent per Month:</span>
                <span className="font-black text-cyan-700 text-sm">KSh {p.rentPerMonth.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-500">
                <span>Occupancy:</span>
                <span className="font-semibold text-slate-800">{p.totalUnits - p.availableUnits} / {p.totalUnits} Units Occupied</span>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
