import React, { useState } from 'react';
import { Property, User } from '../types';
import { PropertyCard } from '../components/PropertyCard';
import { Search, Sparkles, Home, ShieldCheck } from 'lucide-react';

interface PropertyExplorerProps {
  properties: Property[];
  currentUser: User;
  onSelectProperty: (property: Property) => void;
}

const CITY_ESTATES_MAP: Record<string, string[]> = {
  All: [
    'All Estates',
    'Kilimani',
    'Westlands',
    'Lavington',
    'Upper Hill',
    'Karen',
    'South B',
    'Nyali',
    'Bamburi',
    'Milimani',
    'Elgon View',
    'Section 58',
    'Landless',
  ],
  Nairobi: [
    'All Estates',
    'Kilimani',
    'Westlands',
    'Lavington',
    'Upper Hill',
    'Karen',
    'South B',
    'South C',
    'Parklands',
    'Kileleshwa',
    'Ngong Road',
    'Ruaraka',
    'Kasarani',
    'Kitisuru',
  ],
  Mombasa: [
    'All Estates',
    'Nyali',
    'Bamburi',
    'Tudor',
    'Shanzu',
    'Kisauni',
    'Mvita',
    'Likoni',
    'Diani',
  ],
  Kisumu: [
    'All Estates',
    'Milimani',
    'Riat Hills',
    'Mamboleo',
    'Kisian',
    'Tom Mboya',
    'Lolwe',
  ],
  Eldoret: [
    'All Estates',
    'Elgon View',
    'Kapsoya',
    'Kipkaren',
    'Huruma',
    'Pioneer',
  ],
  Nakuru: [
    'All Estates',
    'Milimani',
    'Section 58',
    'Kiamunyi',
    'Naka',
    'Lanet',
  ],
  Thika: [
    'All Estates',
    'Landless',
    'Ngoingwa',
    'Section 9',
    'Makongeni',
    'Thika Town',
  ],
  Kisii: [
    'All Estates',
    'Milimani',
    'Nyanchwa',
    'Jogoo',
    'Daraja Mbili',
  ],
};

export const PropertyExplorer: React.FC<PropertyExplorerProps> = ({
  properties,
  currentUser,
  onSelectProperty,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [selectedEstate, setSelectedEstate] = useState<string>('All Estates');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [maxRent, setMaxRent] = useState<number>(100000);

  const handleCityChange = (city: string) => {
    setSelectedCity(city);
    setSelectedEstate('All Estates');
  };

  const filteredProperties = properties.filter((p) => {
    const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCity = selectedCity === 'All' || p.city === selectedCity;
    const matchesEstate =
      selectedEstate === 'All' ||
      selectedEstate === 'All Estates' ||
      p.location.toLowerCase().includes(selectedEstate.toLowerCase()) ||
      p.title.toLowerCase().includes(selectedEstate.toLowerCase());
    const matchesType = selectedType === 'All' || p.type === selectedType;
    const matchesRent = p.rentPerMonth <= maxRent;
    return matchesSearch && matchesCity && matchesEstate && matchesType && matchesRent;
  });

  return (
    <div className="space-y-6">
      
      {/* Hero Banner Search */}
      <div className="relative rounded-3xl overflow-hidden bg-white text-slate-900 p-6 md:p-10 shadow-sm border border-slate-200 text-center">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-cyan-100/60 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -left-20 -top-20 w-80 h-80 bg-emerald-100/50 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl mx-auto space-y-4 flex flex-col items-center">
          
          <div className="space-y-1.5 max-w-2xl mx-auto text-center">
            <p className="text-xs sm:text-sm font-semibold text-slate-700 leading-relaxed">
              Search for an Apartment, Fill-in the Leasing Agreements, Get Approved, Take a House Tour, Pay Monthly Rent Directly right from the comfort of your computer.
            </p>
            <p className="text-xs sm:text-sm font-extrabold text-teal-700">
              No Brokers, No bureaucracies, No Conmen or annoying Tenants in between!
            </p>
          </div>

          {/* Search bar */}
          <div className="pt-2">
            <div className="bg-white text-slate-900 rounded-2xl p-2.5 shadow-md flex flex-col sm:flex-row items-center gap-2 border border-slate-200">
              <div className="flex-1 flex items-center px-3 gap-2 w-full">
                <Search className="w-5 h-5 text-cyan-600 shrink-0" />
                <input
                  type="text"
                  placeholder="Search by neighborhood, street or city (e.g. Kilimani, Westlands, Nyali)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full text-xs font-medium focus:outline-none py-2 bg-transparent text-slate-900 placeholder:text-slate-400"
                />
              </div>

              <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full sm:w-auto shrink-0">
                <select
                  value={selectedCity}
                  onChange={(e) => handleCityChange(e.target.value)}
                  className="bg-slate-50 font-bold text-xs py-2.5 px-3 rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:border-cyan-600"
                >
                  <option value="All">All Cities</option>
                  <option value="Nairobi">Nairobi</option>
                  <option value="Mombasa">Mombasa</option>
                  <option value="Kisumu">Kisumu</option>
                  <option value="Eldoret">Eldoret</option>
                  <option value="Nakuru">Nakuru</option>
                  <option value="Thika">Thika</option>
                  <option value="Kisii">Kisii</option>
                </select>

                <select
                  value={selectedEstate}
                  onChange={(e) => setSelectedEstate(e.target.value)}
                  className="bg-slate-50 font-bold text-xs py-2.5 px-3 rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:border-cyan-600"
                >
                  {(CITY_ESTATES_MAP[selectedCity] || CITY_ESTATES_MAP['All']).map((estate) => (
                    <option key={estate} value={estate}>
                      {estate === 'All Estates' ? 'All Estates' : estate}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="bg-slate-50 font-bold text-xs py-2.5 px-3 rounded-xl border border-slate-200 text-slate-800 focus:outline-none focus:border-cyan-600"
                >
                  <option value="All">All Categories</option>
                  <option value="1 Bedroom Apartment">1 Bedroom Apartment</option>
                  <option value="2 Bedroom Apartment">2 Bedroom Apartment</option>
                  <option value="3 Bedroom Apartment">3 Bedroom Apartment</option>
                  <option value="Studio">Studio</option>
                  <option value="Bedsitter">Bedsitter</option>
                  <option value="Single Room">Single Room</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar & Results Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pt-2">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">Available Rental Houses in Kenya</h2>
          <p className="text-xs text-slate-500 font-medium">
            Showing {filteredProperties.length} verified listings with M-Pesa automated rent settlement
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <span className="font-bold text-slate-600">Max Rent:</span>
          <input
            type="range"
            min={10000}
            max={100000}
            step={5000}
            value={maxRent}
            onChange={(e) => setMaxRent(Number(e.target.value))}
            className="accent-cyan-600 w-32 cursor-pointer"
          />
          <span className="font-extrabold text-cyan-800 bg-cyan-50 px-3 py-1 rounded-xl border border-cyan-200 shadow-xs">
            KSh {maxRent.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Listings Grid */}
      {filteredProperties.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProperties.map((p) => (
            <PropertyCard key={p.id} property={p} onSelect={onSelectProperty} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3 shadow-xs">
          <Home className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="font-bold text-slate-900 text-base">No Matching Properties Found</h3>
          <p className="text-xs text-slate-500">Try adjusting your city or category filter to explore more Kenyan homes.</p>
        </div>
      )}

    </div>
  );
};
