import React from 'react';
import { User, Lease, Payment, CreditScore } from '../types';
import { Home, FileText, Smartphone, CheckCircle2, ShieldCheck, Clock } from 'lucide-react';

interface TenantDashboardProps {
  tenant: User;
  lease: Lease | null;
  payments: Payment[];
  creditScore: CreditScore;
  onOpenMpesaModal: (amount: number) => void;
  onOpenReceipt: (payment: Payment) => void;
}

export const TenantDashboard: React.FC<TenantDashboardProps> = ({
  tenant,
  lease,
  payments,
  creditScore,
  onOpenMpesaModal,
  onOpenReceipt,
}) => {
  return (
    <div className="space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="relative z-10">
          <span className="text-[10px] font-extrabold text-cyan-800 uppercase tracking-widest bg-cyan-50 px-2.5 py-1 rounded-md border border-cyan-200">
            TENANT PORTAL
          </span>
          <h1 className="text-2xl font-black mt-2 text-slate-900">Karibu, {tenant.name}!</h1>
          <p className="text-xs text-slate-600 mt-1">
            National ID: <span className="font-mono text-slate-900 font-bold">{tenant.nationalId}</span> &bull; Registered Phone: <span className="text-slate-900 font-bold">{tenant.phone}</span>
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <div className="bg-cyan-50 border border-cyan-200 p-3 rounded-xl text-right">
            <p className="text-[10px] text-cyan-800 font-bold uppercase">Rent Rating</p>
            <p className="text-lg font-black text-cyan-800">{creditScore.rating}</p>
          </div>
        </div>
      </div>

      {/* Active Lease & Rent Payment Card */}
      {lease ? (
        <div className="bg-white text-slate-900 rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-200 pb-4 gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-cyan-50 text-cyan-800 text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase border border-cyan-200">
                  Active Lease &bull; Unit {lease.unitNumber}
                </span>
                <span className="text-xs text-slate-500 font-mono">Lease ID: {lease.id}</span>
              </div>
              <h2 className="text-xl font-black text-slate-900 mt-2">{lease.propertyTitle}</h2>
              <p className="text-xs text-slate-500 mt-0.5">Lease Started: {lease.startDate} &bull; Due Day: {lease.dueDateDay}th of every month</p>
            </div>

            <div className="text-right">
              <p className="text-xs text-slate-500 font-medium">Monthly Rent Rate</p>
              <p className="text-2xl font-black text-cyan-700">KSh {lease.rentAmount.toLocaleString()}</p>
            </div>
          </div>

          {/* Payment Status Alert Banner */}
          <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-600 animate-ping"></span>
                <span className="text-xs font-bold text-cyan-800 uppercase tracking-wider">Current Month Rent Status</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                {lease.paymentStatusForCurrentMonth === 'paid' ? 'Rent Paid in Full' : 'Rent Payment Due'}
              </h3>
              <p className="text-xs text-slate-600">
                {lease.paymentStatusForCurrentMonth === 'paid'
                  ? 'Your M-Pesa payment was processed. Your digital receipt is available below.'
                  : `Please pay KSh ${lease.rentAmount.toLocaleString()} before the 5th to keep your tenancy account current.`}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                onClick={() => onOpenMpesaModal(lease.rentAmount)}
                className="px-6 py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl text-xs shadow-sm transition-all flex items-center gap-2"
              >
                <Smartphone className="w-4 h-4 text-white" />
                <span>Pay Rent via M-Pesa STK Push</span>
              </button>
            </div>
          </div>

        </div>
      ) : (
        <div className="bg-white border border-slate-200 p-6 rounded-2xl text-center space-y-2 shadow-xs">
          <Home className="w-8 h-8 text-cyan-600 mx-auto" />
          <h3 className="font-bold text-slate-900 text-base">No Active Lease Connected</h3>
          <p className="text-xs text-slate-500">Browse available properties and fill a tenant lease application form to get started.</p>
        </div>
      )}

      {/* Payment History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-600" />
            Recent Rent Payments & Receipts
          </h3>
          <span className="text-xs text-slate-500 font-medium">{payments.length} Records</span>
        </div>

        <div className="space-y-2.5">
          {payments.map((p) => (
            <div
              key={p.id}
              onClick={() => onOpenReceipt(p)}
              className="p-3.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-xs">{p.month} {p.year} Rent</span>
                  <span className="bg-cyan-100 text-cyan-900 text-[10px] font-bold px-2 py-0.5 rounded border border-cyan-200 font-mono">
                    {p.mpesaReceiptNumber}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">{p.method} &bull; {p.date}</p>
              </div>

              <div className="text-right">
                <p className="font-black text-cyan-700 text-sm">KSh {p.amount.toLocaleString()}</p>
                <span className="text-[10px] text-cyan-700 font-extrabold hover:underline">View Official Receipt &rarr;</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
