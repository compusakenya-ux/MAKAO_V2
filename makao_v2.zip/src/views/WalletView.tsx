import React, { useState } from 'react';
import { User, WalletTransaction } from '../types';
import { Wallet, ArrowDownLeft, ArrowUpRight, ShieldCheck } from 'lucide-react';

interface WalletViewProps {
  user: User;
  transactions: WalletTransaction[];
  onTopUp: (amount: number, phone: string) => void;
  onWithdraw: (amount: number, phone: string) => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  user,
  transactions,
  onTopUp,
  onWithdraw,
}) => {
  const [activeAction, setActiveAction] = useState<'topup' | 'withdraw'>('topup');
  const [amount, setAmount] = useState<number>(5000);
  const [phone, setPhone] = useState(user.phone || '+254712345678');
  const [statusMsg, setStatusMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeAction === 'topup') {
      onTopUp(amount, phone);
      setStatusMsg(`M-Pesa STK Topup request for KSh ${amount.toLocaleString()} sent to ${phone}`);
    } else {
      if (amount > user.walletBalance) {
        setStatusMsg('Insufficient wallet balance for withdrawal.');
        return;
      }
      onWithdraw(amount, phone);
      setStatusMsg(`Withdrew KSh ${amount.toLocaleString()} to M-Pesa number ${phone}`);
    }
    setTimeout(() => setStatusMsg(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Wallet Balance Hero Card */}
      <div className="bg-white text-slate-900 rounded-2xl p-6 md:p-8 shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <span className="text-xs font-bold text-cyan-800 uppercase tracking-widest flex items-center gap-1.5 bg-cyan-50 px-2.5 py-1 rounded-md border border-cyan-200 w-fit">
            <Wallet className="w-4 h-4 text-cyan-600" /> MAKAO EXPRESS WALLET
          </span>
          <p className="text-xs text-slate-500 font-medium pt-1">Available Rent Balance</p>
          <p className="text-4xl font-black text-slate-900">
            KSh {user.walletBalance.toLocaleString()}
          </p>
          <p className="text-xs text-slate-600 font-semibold pt-1">
            Linked M-Pesa Mobile: <span className="font-mono text-slate-900 font-bold">{user.phone}</span>
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2 text-xs">
          <div className="flex items-center gap-2 text-cyan-800 font-extrabold">
            <ShieldCheck className="w-4 h-4 text-cyan-600" />
            <span>Instant Rent Auto-Deduction</span>
          </div>
          <p className="text-slate-600 max-w-xs font-medium">
            Keep funds in your Makao Wallet to automatically settle monthly rent on the 1st of every month.
          </p>
        </div>
      </div>

      {/* Action Form & Transaction Log Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Action Panel */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold border border-slate-200">
            <button
              type="button"
              onClick={() => setActiveAction('topup')}
              className={`flex-1 py-2 rounded-lg transition-all ${
                activeAction === 'topup' ? 'bg-white text-cyan-900 shadow-xs border border-slate-200' : 'text-slate-600'
              }`}
            >
              M-Pesa Top Up
            </button>
            <button
              type="button"
              onClick={() => setActiveAction('withdraw')}
              className={`flex-1 py-2 rounded-lg transition-all ${
                activeAction === 'withdraw' ? 'bg-white text-cyan-900 shadow-xs border border-slate-200' : 'text-slate-600'
              }`}
            >
              Withdraw
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Amount (KSh)
              </label>
              <input
                type="number"
                min={100}
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-base font-black text-cyan-700 focus:outline-none focus:border-cyan-600"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                M-Pesa Number
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 font-mono"
              />
            </div>

            {statusMsg && (
              <p className="text-xs bg-cyan-50 text-cyan-900 p-2.5 rounded-lg font-semibold border border-cyan-200">
                {statusMsg}
              </p>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl text-xs shadow-sm transition-all"
            >
              {activeAction === 'topup' ? 'Top Up via M-Pesa STK' : 'Withdraw Funds to M-Pesa'}
            </button>
          </form>
        </div>

        {/* Transactions History */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Wallet Activity Ledger</h3>

          <div className="space-y-2.5">
            {transactions.map((t) => (
              <div key={t.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-xl bg-white text-cyan-700 border border-slate-200 shadow-xs">
                    {t.type === 'topup' ? <ArrowDownLeft className="w-4 h-4 text-cyan-600" /> : <ArrowUpRight className="w-4 h-4 text-cyan-600" />}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">{t.description}</p>
                    <p className="text-[10px] text-slate-500">{t.paymentMethod} &bull; Ref: {t.referenceCode} &bull; {t.date}</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-black text-sm text-cyan-700">
                    {t.type === 'topup' ? '+' : '-'} KSh {t.amount.toLocaleString()}
                  </p>
                  <span className="text-[10px] text-cyan-800 bg-cyan-100 border border-cyan-200 font-bold px-2 py-0.5 rounded uppercase">
                    {t.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
