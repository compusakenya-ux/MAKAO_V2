import React from 'react';
import { User, Property, Payment, CreditScore } from '../types';
import { Users, Smartphone, ShieldCheck } from 'lucide-react';

interface AdminDashboardProps {
  users: User[];
  properties: Property[];
  payments: Payment[];
  creditScore: CreditScore;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  users,
  properties,
  payments,
}) => {
  const totalVolume = payments.reduce((acc, p) => acc + p.amount, 0);
  const totalPlatformFees = totalVolume * 0.015; // 1.5% platform transaction fee

  return (
    <div className="space-y-6">
      
      {/* Admin Banner */}
      <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-cyan-800 uppercase tracking-widest bg-cyan-50 px-2.5 py-1 rounded-md border border-cyan-200">SYSTEM ADMIN CONSOLE</span>
          <h1 className="text-2xl font-black mt-2 text-slate-900">MAKAO Platform Control Room</h1>
          <p className="text-xs text-slate-600 mt-1">M-Pesa Express B2C / C2B Gateway & System Registry Engine &bull; A Sena Global Limited Company</p>
        </div>

        <div className="bg-cyan-50 border border-cyan-200 px-3.5 py-2 rounded-xl text-cyan-800 text-xs font-bold flex items-center gap-2 self-start sm:self-auto">
          <span className="w-2 h-2 rounded-full bg-cyan-600 animate-ping"></span>
          <span>M-Pesa API Status: ONLINE</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Gross Rent Transacted</p>
          <p className="text-2xl font-black text-slate-900">KSh {totalVolume.toLocaleString()}</p>
          <p className="text-[10px] text-cyan-800 font-bold">100% Settled via M-Pesa</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Makao Revenue (1.5% Fee)</p>
          <p className="text-2xl font-black text-cyan-700">KSh {totalPlatformFees.toLocaleString()}</p>
          <p className="text-[10px] text-slate-500 font-medium">Platform commission balance</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Registered Users</p>
          <p className="text-2xl font-black text-slate-900">{users.length} Accounts</p>
          <p className="text-[10px] text-slate-500 font-medium">Tenants & Landlords verified</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-slate-500">Active Listed Properties</p>
          <p className="text-2xl font-black text-cyan-700">{properties.length} Properties</p>
          <p className="text-[10px] text-slate-500 font-medium">Across Nairobi, Mombasa & Kisumu</p>
        </div>
      </div>

      {/* M-Pesa Gateway Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Transaction Ledger */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-cyan-600" />
            Live M-Pesa STK Push Settlement Logs
          </h3>

          <div className="space-y-2.5 text-xs">
            {payments.map((p) => (
              <div key={p.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center">
                <div>
                  <p className="font-bold text-slate-900">{p.tenantName} ({p.phoneNumber})</p>
                  <p className="text-[10px] text-slate-500">M-Pesa Code: <span className="font-mono text-cyan-800 font-bold">{p.mpesaReceiptNumber}</span> &bull; {p.date}</p>
                </div>
                <div className="text-right">
                  <p className="font-black text-cyan-700">KSh {p.amount.toLocaleString()}</p>
                  <span className="bg-cyan-100 text-cyan-800 border border-cyan-200 text-[10px] font-bold px-2 py-0.5 rounded">SUCCESS</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* User Account Registry */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Users className="w-5 h-5 text-cyan-600" />
            System User Accounts
          </h3>

          <div className="space-y-2.5 text-xs">
            {users.map((u) => (
              <div key={u.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <img src={u.avatar} alt={u.name} className="w-8 h-8 rounded-full object-cover border border-slate-200" />
                  <div>
                    <p className="font-bold text-slate-900">{u.name}</p>
                    <p className="text-[10px] text-slate-500 capitalize">{u.role} &bull; ID: {u.nationalId}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-cyan-700">KSh {u.walletBalance.toLocaleString()}</p>
                  <span className="text-[10px] text-slate-500">Wallet Balance</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
