import { Property, User, Lease, Payment, CreditScore, WalletTransaction, LeaseApplication } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'u_tenant_1',
    name: 'John Kamau',
    email: 'john.kamau@gmail.com',
    phone: '+254712345678',
    role: 'tenant',
    nationalId: '12345678',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    walletBalance: 18500,
  },
  {
    id: 'u_landlord_1',
    name: 'Grace Wambui (Makao Properties)',
    email: 'grace.wambui@makaoproperties.co.ke',
    phone: '+254722987654',
    role: 'landlord',
    nationalId: '87654321',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    walletBalance: 245000,
  },
  {
    id: 'u_admin_1',
    name: 'Makao Admin',
    email: 'admin@makao.co.ke',
    phone: '+254700000000',
    role: 'admin',
    nationalId: '11223344',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    walletBalance: 48000,
  }
];

export const INITIAL_PROPERTIES: Property[] = [
  {
    id: 'prop_1',
    title: 'Kilimani Executive 2 Bedroom Apartment',
    location: 'Kilimani, Argwings Kodhek Rd',
    city: 'Nairobi',
    type: '2 Bedroom Apartment',
    rentPerMonth: 45000,
    depositAmount: 45000,
    bedrooms: 2,
    bathrooms: 2,
    amenities: ['24/7 Security', 'Borehole Water', 'High-speed Fiber', 'Backup Generator', 'Balcony', 'Parking Spot'],
    imageUrls: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&auto=format&fit=crop&q=80',
    ],
    landlordId: 'u_landlord_1',
    landlordName: 'Grace Wambui',
    landlordPhone: '+254722987654',
    availableUnits: 3,
    totalUnits: 12,
    description: 'Modern spacious 2 bedroom apartment in the heart of Kilimani. Comes with master en-suite, fitted kitchen cabinets, and serene city views.',
    featured: true,
  },
  {
    id: 'prop_2',
    title: 'Westlands Greenview Studio',
    location: 'Westlands, Rhapta Road',
    city: 'Nairobi',
    type: 'Studio',
    rentPerMonth: 28000,
    depositAmount: 28000,
    bedrooms: 1,
    bathrooms: 1,
    amenities: ['CCTV Surveillance', 'Solar Water Heating', 'Gym Access', 'High Speed Wifi'],
    imageUrls: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&auto=format&fit=crop&q=80'
    ],
    landlordId: 'u_landlord_1',
    landlordName: 'Grace Wambui',
    landlordPhone: '+254722987654',
    availableUnits: 1,
    totalUnits: 8,
    description: 'Ultra-modern compact studio ideal for working professionals in Westlands. Close to Westgate and Sarit Centre.',
    featured: true,
  },
  {
    id: 'prop_3',
    title: 'Nyali Ocean Breeze 3 Bedroom Apartment',
    location: 'Nyali, Beach Road',
    city: 'Mombasa',
    type: '3 Bedroom Apartment',
    rentPerMonth: 65000,
    depositAmount: 65000,
    bedrooms: 3,
    bathrooms: 3,
    amenities: ['Air Conditioning', 'Swimming Pool', 'Ocean View', 'Perimeter Wall', 'Electric Fence'],
    imageUrls: [
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=800&auto=format&fit=crop&q=80'
    ],
    landlordId: 'u_landlord_1',
    landlordName: 'Grace Wambui',
    landlordPhone: '+254722987654',
    availableUnits: 2,
    totalUnits: 4,
    description: 'Luxury coastal living 3 bedroom apartment with ocean breeze, private swimming pool, landscaped lawn, and top tier 24hr security.',
  },
  {
    id: 'prop_4',
    title: 'Lavington Prime 1 Bedroom Apartment',
    location: 'Lavington, James Gichuru Road',
    city: 'Nairobi',
    type: '1 Bedroom Apartment',
    rentPerMonth: 38000,
    depositAmount: 38000,
    bedrooms: 1,
    bathrooms: 1,
    amenities: ['24/7 Security', 'Borehole', 'Spacious Balcony', 'Elevator', 'Gym'],
    imageUrls: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&auto=format&fit=crop&q=80'
    ],
    landlordId: 'u_landlord_1',
    landlordName: 'Grace Wambui',
    landlordPhone: '+254722987654',
    availableUnits: 2,
    totalUnits: 6,
    description: 'Elegantly finished 1 bedroom apartment in Lavington with custom wardrobes, bright open plan kitchen and high speed internet.',
    featured: true,
  },
  {
    id: 'prop_5',
    title: 'Milimani Sunset Single Room',
    location: 'Milimani Estate, Ring Rd',
    city: 'Kisumu',
    type: 'Single Room',
    rentPerMonth: 22000,
    depositAmount: 22000,
    bedrooms: 1,
    bathrooms: 1,
    amenities: ['Lake View', 'Gated Community', 'Ample Parking', 'Constant Water Supply'],
    imageUrls: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&auto=format&fit=crop&q=80'
    ],
    landlordId: 'u_landlord_1',
    landlordName: 'Grace Wambui',
    landlordPhone: '+254722987654',
    availableUnits: 4,
    totalUnits: 10,
    description: 'Quiet & serene room in Milimani, Kisumu with a glimpse of Lake Victoria.',
  },
  {
    id: 'prop_6',
    title: 'Eldoret Elgon View Bedsitter',
    location: 'Elgon View, Off Uganda Rd',
    city: 'Eldoret',
    type: 'Bedsitter',
    rentPerMonth: 18000,
    depositAmount: 18000,
    bedrooms: 1,
    bathrooms: 1,
    amenities: ['Private Garden', 'Security Guard', 'Water Tank Storage', 'Fiber Internet'],
    imageUrls: [
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&auto=format&fit=crop&q=80'
    ],
    landlordId: 'u_landlord_1',
    landlordName: 'Grace Wambui',
    landlordPhone: '+254722987654',
    availableUnits: 2,
    totalUnits: 6,
    description: 'Affordable modern bedsitter housing in Elgon View with lush greenery and easy access to Eldoret town center.',
  }
];

export const INITIAL_LEASES: Lease[] = [
  {
    id: 'lease_101',
    tenantId: 'u_tenant_1',
    landlordId: 'u_landlord_1',
    propertyId: 'prop_1',
    propertyTitle: 'Kilimani Executive 2 Bedroom Apartment',
    unitNumber: 'A-402',
    rentAmount: 45000,
    depositAmount: 45000,
    startDate: '2025-01-01',
    dueDateDay: 5,
    status: 'active',
    paymentStatusForCurrentMonth: 'due',
  }
];

export const INITIAL_LEASE_APPLICATIONS: LeaseApplication[] = [
  {
    id: 'app_1',
    propertyId: 'prop_1',
    propertyTitle: 'Kilimani Executive 2 Bedroom Apartment',
    unitNumber: 'A-402',
    tenantId: 'u_tenant_1',
    fullName: 'John Kamau',
    email: 'john.kamau@example.com',
    nationalId: '12345678',
    phone: '+254712345678',
    emergencyContactName: 'Peter Kamau (Brother)',
    emergencyContactPhone: '+254720112233',
    sourceOfIncome: 'Employed',
    employerName: 'Kenya Commercial Bank',
    employerContactPhone: '+254722000000',
    documents: [
      { docType: 'National ID', fileName: 'National_ID_JohnKamau.pdf' },
      { docType: 'Payslip/Employer Contract', fileName: 'Employment_Contract.pdf' },
      { docType: 'Face Photo', fileName: 'John_Passport_Photo.jpg' },
    ],
    appliedDate: '2026-07-20',
    status: 'pending'
  }
];

export const INITIAL_PAYMENTS: Payment[] = [
  {
    id: 'pay_1',
    leaseId: 'lease_101',
    tenantId: 'u_tenant_1',
    tenantName: 'John Kamau',
    propertyTitle: 'Kilimani Executive 2 Bedroom Apartment',
    unitNumber: 'A-402',
    amount: 45000,
    date: '2026-06-03 10:14:22',
    method: 'M-Pesa',
    mpesaReceiptNumber: 'SGI89X42LK',
    phoneNumber: '+254712345678',
    status: 'completed',
    month: 'June',
    year: 2026,
  },
  {
    id: 'pay_2',
    leaseId: 'lease_101',
    tenantId: 'u_tenant_1',
    tenantName: 'John Kamau',
    propertyTitle: 'Kilimani Executive 2 Bedroom Apartment',
    unitNumber: 'A-402',
    amount: 45000,
    date: '2026-05-08 14:20:10',
    method: 'M-Pesa',
    mpesaReceiptNumber: 'RFH73P19MM',
    phoneNumber: '+254712345678',
    status: 'completed',
    month: 'May',
    year: 2026,
  },
  {
    id: 'pay_3',
    leaseId: 'lease_101',
    tenantId: 'u_tenant_1',
    tenantName: 'John Kamau',
    propertyTitle: 'Kilimani Executive 2 Bedroom Apartment',
    unitNumber: 'A-402',
    amount: 45000,
    date: '2026-04-02 09:45:00',
    method: 'M-Pesa',
    mpesaReceiptNumber: 'QEK12M88NN',
    phoneNumber: '+254712345678',
    status: 'completed',
    month: 'April',
    year: 2026,
  }
];

export const INITIAL_CREDIT_SCORE: CreditScore = {
  tenantId: 'u_tenant_1',
  nationalId: '12345678',
  fullName: 'John Kamau',
  score: 465, // Out of 500 scale used in Makao
  totalPayments: 24,
  onTimePayments: 22,
  latePayments: 2,
  totalDaysLate: 7,
  rating: 'Excellent',
  lastUpdated: new Date().toISOString(),
  history: [
    {
      id: 'ce_1',
      month: 'July',
      year: 2026,
      daysLate: 0,
      pointsDeducted: 0,
      status: 'On Time',
      amount: 45000,
      receiptNumber: 'SGI89X42LK',
      date: '2026-07-03'
    },
    {
      id: 'ce_2',
      month: 'June',
      year: 2026,
      daysLate: 0,
      pointsDeducted: 0,
      status: 'On Time',
      amount: 45000,
      receiptNumber: 'SGI89X42LK',
      date: '2026-06-03'
    },
    {
      id: 'ce_3',
      month: 'May',
      year: 2026,
      daysLate: 3,
      pointsDeducted: 15,
      status: 'Late',
      amount: 45000,
      receiptNumber: 'RFH73P19MM',
      date: '2026-05-08'
    },
    {
      id: 'ce_4',
      month: 'April',
      year: 2026,
      daysLate: 0,
      pointsDeducted: 0,
      status: 'On Time',
      amount: 45000,
      receiptNumber: 'QEK12M88NN',
      date: '2026-04-02'
    }
  ]
};

export const INITIAL_WALLET_TRANSACTIONS: WalletTransaction[] = [
  {
    id: 'wt_1',
    userId: 'u_tenant_1',
    type: 'topup',
    amount: 20000,
    description: 'M-Pesa Express Topup (254712345678)',
    date: '2026-07-01 11:30',
    status: 'completed',
    referenceCode: 'SGH99321AB',
    paymentMethod: 'M-Pesa'
  }
];
