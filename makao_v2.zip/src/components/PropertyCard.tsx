import React from 'react';
import { Property } from '../types';
import { MapPin, Bed, Bath, ArrowRight } from 'lucide-react';

interface PropertyCardProps {
  property: Property;
  onSelect: (property: Property) => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, onSelect }) => {
  return (
    <div
      onClick={() => onSelect(property)}
      className="group bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl hover:border-cyan-300 transition-all duration-300 overflow-hidden cursor-pointer flex flex-col h-full"
    >
      {/* Image Container */}
      <div className="relative h-48 w-full overflow-hidden bg-slate-100">
        <img
          src={property.imageUrls[0] || 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800'}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap">
          <span className="bg-white/95 backdrop-blur-md text-slate-800 text-[11px] font-extrabold px-2.5 py-1 rounded-full border border-slate-200 shadow-xs">
            {property.city}
          </span>
          <span className="bg-cyan-600 text-white text-[11px] font-extrabold px-2.5 py-1 rounded-full shadow-xs">
            {property.type}
          </span>
        </div>
        {property.featured && (
          <span className="absolute top-3 right-3 bg-amber-500 text-slate-950 text-[10px] font-black px-2.5 py-1 rounded-full shadow uppercase tracking-wider">
            Featured
          </span>
        )}
        <div className="absolute bottom-3 left-3 right-3 bg-white/95 backdrop-blur-md text-slate-900 p-2.5 rounded-xl border border-slate-200 flex items-center justify-between shadow-sm">
          <span className="text-xs text-slate-500 font-medium">Monthly Rent</span>
          <span className="text-base font-black text-cyan-700">
            KSh {property.rentPerMonth.toLocaleString()} <span className="text-[10px] text-slate-500 font-normal">/mo</span>
          </span>
        </div>
      </div>

      {/* Body Content */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <h3 className="font-extrabold text-slate-900 text-base group-hover:text-cyan-700 transition-colors line-clamp-1">
            {property.title}
          </h3>
          <p className="text-xs text-slate-500 flex items-center gap-1 mt-1 font-medium">
            <MapPin className="w-3.5 h-3.5 text-cyan-600 shrink-0" />
            <span className="truncate">{property.location}</span>
          </p>
        </div>

        {/* Property Features */}
        <div className="flex items-center gap-4 text-xs font-semibold text-slate-600 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1">
            <Bed className="w-4 h-4 text-cyan-600" />
            <span>{property.bedrooms} Bed</span>
          </div>
          <div className="flex items-center gap-1">
            <Bath className="w-4 h-4 text-cyan-600" />
            <span>{property.bathrooms} Bath</span>
          </div>
          <div className="ml-auto text-[10px] font-bold text-cyan-800 bg-cyan-50 px-2.5 py-1 rounded-full border border-cyan-200">
            {property.availableUnits} Vacant Units
          </div>
        </div>

        {/* Verification badge & View Property link */}
        <div className="flex items-center justify-between pt-2 text-xs border-t border-slate-100 text-slate-600">
          <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
            Verified Listing
          </span>
          <span className="text-cyan-700 font-extrabold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
            View Property <ArrowRight className="w-3.5 h-3.5 text-cyan-600" />
          </span>
        </div>
      </div>
    </div>
  );
};
