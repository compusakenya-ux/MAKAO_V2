import React, { useState, useEffect } from 'react';
import { X, Smartphone, CheckCircle, Loader2, ShieldCheck, ArrowRight } from 'lucide-react';
import { Payment } from '../types';

interface MpesaModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  phone: string;
  leaseInfo?: {
    propertyTitle: string;
    unitNumber: string;
    leaseId: string;
    tenantName: string;
  };
  onSuccess: (payment: Payment) => void;
}

export const MpesaModal: React.FC<MpesaModalProps> = ({
  isOpen,
  onClose,
  amount,
  phone: initialPhone,
  leaseInfo,
  onSuccess,
}) => {
  const [phoneNumber, setPhoneNumber] = useState(initialPhone || '+254712345678');
  const [step, setStep] = useState<'init' | 'stk_sent' | 'processing' | 'completed' | 'failed'>('init');
  const [pinCode, setPinCode] = useState('');
  const [countdown, setCountdown] = useState(15);
  const [generatedReceipt, setGeneratedReceipt] = useState<Payment | null>(null);

  useEffect(() => {
    if (initialPhone) {
      setPhoneNumber(initialPhone);
    }
  }, [initialPhone]);

  useEffect(() => {
    let timer: any;
    if (step === 'stk_sent' && countdown > 0) {
      timer = setInterval(() => setCountdown((c) => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  if (!isOpen) return null;

  const handleSendStkPush = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('stk_sent');
    setCountdown(20);
  };

  const handleSimulatePinSubmit = () => {
    setStep('processing');
    setTimeout(() => {
      const receiptCode = 'MK' + Math.random().toString(36).substring(2, 9).toUpperCase();
      const newPayment: Payment = {
        id: 'pay_' + Date.now(),
        leaseId: leaseInfo?.leaseId || 'lease_101',
        tenantId: 'u_tenant_1',
        tenantName: leaseInfo?.tenantName || 'John Kamau',
        propertyTitle: leaseInfo?.propertyTitle || 'Kilimani Executive 2 Bedroom Apartment',
        unitNumber: leaseInfo?.unitNumber || 'A-402',
        amount: amount,
        date: new Date().toISOString().replace('T', ' ').substring(0, 19),
        method: 'M-Pesa',
        mpesaReceiptNumber: receiptCode,
        phoneNumber: phoneNumber,
        status: 'completed',
        month: new Date().toLocaleString('default', { month: 'long' }),
        year: new Date().getFullYear(),
      };
      setGeneratedReceipt(newPayment);
      setStep('completed');
      onSuccess(newPayment);
    }, 2500);
  };

  const handleReset = () => {
    setStep('init');
    setPinCode('');
    setGeneratedReceipt(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white border border-slate-200 text-slate-900 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="bg-slate-900 text-white border-b border-slate-800 p-5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-600 flex items-center justify-center font-black text-lg text-white shadow-sm">
              S
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight text-white">M-Pesa Express Payment</h3>
              <p className="text-xs text-cyan-300 font-semibold">M-Pesa Direct STK Push Gateway</p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="text-slate-300 hover:text-white p-1.5 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6">
          {step === 'init' && (
            <form onSubmit={handleSendStkPush} className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
                <p className="text-xs text-slate-500 font-semibold">Payment Details</p>
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-extrabold text-slate-900">
                    {leaseInfo ? `${leaseInfo.propertyTitle} (${leaseInfo.unitNumber})` : 'Rent Payment'}
                  </span>
                  <span className="text-lg font-black text-cyan-700">
                    KSh {amount.toLocaleString()}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  M-Pesa Registered Phone Number
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400 font-bold text-sm">🇰🇪</span>
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    required
                    placeholder="+254712345678"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm font-bold text-slate-900 focus:outline-none focus:border-cyan-600 font-mono"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  You will receive an instant M-Pesa STK prompt on this phone.
                </p>
              </div>

              <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-xl flex items-start gap-2 text-xs text-cyan-900 font-medium">
                <ShieldCheck className="w-5 h-5 text-cyan-600 shrink-0 mt-0.5" />
                <span>
                  Paying on time generates an official digital M-Pesa rent receipt!
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2"
              >
                <span>Trigger STK Push Prompt</span>
                <ArrowRight className="w-4 h-4 text-white" />
              </button>
            </form>
          )}

          {step === 'stk_sent' && (
            <div className="space-y-5 text-center">
              <div className="w-16 h-16 bg-cyan-50 border border-cyan-200 text-cyan-700 rounded-full flex items-center justify-center mx-auto animate-bounce shadow-sm">
                <Smartphone className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-base font-extrabold text-slate-900">STK Push Sent to Phone</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Check phone <span className="text-cyan-700 font-bold">{phoneNumber}</span> for the M-Pesa popup prompt.
                </p>
              </div>

              {/* Simulated Mobile Screen Prompt */}
              <div className="bg-slate-900 text-white rounded-2xl p-4 text-left space-y-3 shadow-md">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-[11px] font-bold text-cyan-400 tracking-wider">M-PESA EXPRESS</span>
                  <span className="text-[10px] text-slate-400">Time remaining: {countdown}s</span>
                </div>
                <p className="text-xs text-slate-200">
                  Do you want to pay <strong className="text-cyan-300">KSh {amount.toLocaleString()}</strong> to <strong>MAKAO RENTALS LTD (Paybill 889900)</strong> Account <strong>{leaseInfo?.unitNumber || 'RENT-402'}</strong>?
                </p>

                <div className="pt-2">
                  <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                    Enter M-Pesa PIN (Simulated)
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value)}
                    placeholder="••••"
                    className="w-full text-center tracking-widest text-lg bg-slate-950 border border-cyan-500/50 rounded-lg py-1.5 text-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('init')}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold"
                >
                  Cancel / Re-enter
                </button>
                <button
                  type="button"
                  onClick={handleSimulatePinSubmit}
                  className="flex-1 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-extrabold shadow-sm"
                >
                  Confirm PIN & Pay
                </button>
              </div>
            </div>
          )}

          {step === 'processing' && (
            <div className="py-8 text-center space-y-4">
              <Loader2 className="w-12 h-12 text-cyan-600 animate-spin mx-auto" />
              <div>
                <h4 className="text-base font-extrabold text-slate-900">Communicating with M-Pesa Gateway...</h4>
                <p className="text-xs text-slate-500 mt-1">Validating transaction & updating landlord ledger.</p>
              </div>
            </div>
          )}

          {step === 'completed' && generatedReceipt && (
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-200 shadow-sm">
                <CheckCircle className="w-9 h-9" />
              </div>

              <div>
                <h4 className="text-lg font-black text-slate-900">Payment Received!</h4>
                <p className="text-xs text-cyan-700 font-extrabold mt-0.5">
                  Receipt #{generatedReceipt.mpesaReceiptNumber} Confirmed
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-700 space-y-2 text-left">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Amount Paid:</span>
                  <span className="font-extrabold text-slate-900">KSh {generatedReceipt.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Payment Method:</span>
                  <span className="font-extrabold text-cyan-700">M-Pesa Express</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Tenant Name:</span>
                  <span className="font-bold text-slate-900">{generatedReceipt.tenantName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Property / Unit:</span>
                  <span className="font-bold text-slate-900">{generatedReceipt.propertyTitle} ({generatedReceipt.unitNumber})</span>
                </div>
              </div>

              <button
                onClick={handleReset}
                className="w-full py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl shadow-sm transition-all"
              >
                Done & View Dashboard
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
