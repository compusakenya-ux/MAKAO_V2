import React from 'react';
import { X, Printer, ShieldCheck, Award, Star } from 'lucide-react';
import { CreditScore, User } from '../types';

interface CreditCertificateModalProps {
  creditScore: CreditScore;
  tenant: User;
  onClose: () => void;
}

export const CreditCertificateModal: React.FC<CreditCertificateModalProps> = ({
  creditScore,
  tenant,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 text-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-800">
        
        {/* Top Controls */}
        <div className="bg-slate-950 border-b border-slate-800 text-white p-4 flex items-center justify-between no-print">
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-cyan-400" />
            <span className="font-bold text-sm">Official Kenyan Rent Reference & Credit Score Certificate</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-semibold"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Download Certificate</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Printable Sheet */}
        <div className="p-8 space-y-6 bg-slate-950 border-4 border-slate-800 rounded-xl m-4 relative text-slate-200">
          
          {/* Header */}
          <div className="text-center space-y-1">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-slate-900 border border-cyan-500/40 text-cyan-400 font-black text-2xl shadow-[0_0_15px_rgba(6,182,212,0.25)] mb-1">
              M
            </div>
            <h2 className="text-xs font-extrabold text-cyan-400 uppercase tracking-widest">
              REPUBLIC OF KENYA &bull; RENTAL HOUSING REGISTRY
            </h2>
            <h1 className="text-2xl font-black text-white tracking-tight">
              TENANT RENT CREDIT CERTIFICATE
            </h1>
            <p className="text-xs text-slate-400 font-medium">
              Verified Financial & Rent Reliability Report issued by MAKAO Kenya Platform
            </p>
          </div>

          {/* Certificate Main Badge & Score */}
          <div className="bg-slate-900 border border-slate-800 text-white p-6 rounded-2xl shadow-xl flex items-center justify-between">
            <div>
              <p className="text-xs text-cyan-400 font-bold uppercase tracking-wider">Official Rent Credit Score</p>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-5xl font-black text-white">{creditScore.score}</span>
                <span className="text-lg text-slate-400 font-bold">/ 500</span>
              </div>
              <p className="text-xs text-amber-300 font-semibold mt-1 flex items-center gap-1">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> Grade: {creditScore.rating} Tenant Rating
              </p>
            </div>

            <div className="text-right border-l border-slate-800 pl-6 space-y-1">
              <p className="text-xs text-slate-400">Total Tracked Payments</p>
              <p className="text-xl font-black text-cyan-400">{creditScore.onTimePayments} / {creditScore.totalPayments} On-Time</p>
              <p className="text-[11px] text-slate-400">Late Payment Rate: {((creditScore.latePayments / creditScore.totalPayments) * 100).toFixed(1)}%</p>
            </div>
          </div>

          {/* Tenant Details */}
          <div className="grid grid-cols-2 gap-4 text-xs bg-slate-900 p-4 rounded-xl border border-slate-800">
            <div>
              <p className="text-slate-400 font-medium">Full Legal Name:</p>
              <p className="font-bold text-white text-sm">{creditScore.fullName}</p>
            </div>
            <div>
              <p className="text-slate-400 font-medium">National ID Number:</p>
              <p className="font-bold text-white font-mono text-sm">{creditScore.nationalId}</p>
            </div>
            <div>
              <p className="text-slate-400 font-medium">Registered Phone:</p>
              <p className="font-bold text-white">{tenant.phone}</p>
            </div>
            <div>
              <p className="text-slate-400 font-medium">Certificate Issue Date:</p>
              <p className="font-bold text-white">{new Date().toLocaleDateString('en-GB')}</p>
            </div>
          </div>

          {/* Declaration Statement */}
          <div className="text-xs text-slate-300 leading-relaxed bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-sm">
            <p className="font-semibold text-cyan-400 mb-1">Landlord & Agent Verification Notice:</p>
            This document certifies that <strong>{creditScore.fullName}</strong> holds an established rent payment history on the Makao platform. Based on automated M-Pesa ledger records, this tenant demonstrates a <strong>{creditScore.rating.toLowerCase()}</strong> score of <strong>{creditScore.score} points</strong>, making them a highly reliable rental candidate across Kenyan estates.
          </div>

          {/* Official Stamp Footer */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <div className="flex items-center gap-2 text-cyan-400">
              <ShieldCheck className="w-8 h-8 text-cyan-400" />
              <div>
                <p className="text-xs font-bold uppercase text-white">MAKAO CREDIT BUREAU</p>
                <p className="text-[10px] text-slate-400">Secured via M-Pesa Direct API &bull; A Sena Global Limited Company</p>
              </div>
            </div>

            <div className="border border-cyan-500/40 bg-slate-900 px-4 py-2 rounded-lg text-center font-mono text-[10px]">
              <p className="font-bold text-slate-400">VERIFICATION CODE</p>
              <p className="text-cyan-400 font-black">MK-KE-{creditScore.nationalId}-2026</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
