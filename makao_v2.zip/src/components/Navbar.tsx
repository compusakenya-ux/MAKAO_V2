import React from 'react';
import { User } from '../types';
import { Building2, Wallet, Users, Search, Home, PlusCircle, CheckCircle2, ChevronDown } from 'lucide-react';
import { MakaoLogo } from './MakaoLogo';

interface NavbarProps {
  currentUser: User;
  users: User[];
  onSelectUser: (user: User) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAddProperty: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  users,
  onSelectUser,
  activeTab,
  setActiveTab,
  onOpenAddProperty,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white text-slate-900 border-b border-slate-200 shadow-sm backdrop-blur-md">
      {/* Top Banner - Moving Marquee Screen */}
      <div className="bg-slate-950 text-white py-2 overflow-hidden relative border-b border-slate-800 select-none">
        <style>{`
          @keyframes marquee {
            0% { transform: translateX(0%); }
            100% { transform: translateX(-50%); }
          }
          .animate-marquee-smooth {
            display: flex;
            width: 200%;
            animation: marquee 20s linear infinite;
          }
          .animate-marquee-smooth:hover {
            animation-play-state: paused;
          }
        `}</style>
        <div className="animate-marquee-smooth flex items-center gap-8 whitespace-nowrap">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="flex items-center gap-4 text-xs font-black tracking-wide">
              <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent uppercase font-black tracking-widest text-[11px] drop-shadow-sm">
                ✨ Search 47 Counties, 1 Home at Makao
              </span>
              <span className="text-cyan-500 font-bold text-sm">&bull;</span>
              <span className="text-slate-300 font-medium text-[11px]">
                A Sena Global Limited Company
              </span>
              <span className="text-cyan-500 font-bold text-sm">&bull;</span>
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center cursor-pointer" onClick={() => setActiveTab('explore')}>
            <MakaoLogo size="md" showText={true} />
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            <button
              onClick={() => setActiveTab('explore')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'explore'
                  ? 'bg-cyan-50 text-cyan-800 border border-cyan-200 shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Search className="w-4 h-4 text-cyan-600" />
              <span>Explore Homes</span>
            </button>

            {currentUser.role === 'tenant' && (
              <button
                onClick={() => setActiveTab('tenant-dashboard')}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'tenant-dashboard'
                    ? 'bg-cyan-50 text-cyan-800 border border-cyan-200 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Home className="w-4 h-4 text-cyan-600" />
                <span>My Rent & Lease</span>
              </button>
            )}

            {currentUser.role === 'landlord' && (
              <>
                <button
                  onClick={() => setActiveTab('landlord-dashboard')}
                  className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeTab === 'landlord-dashboard'
                      ? 'bg-cyan-50 text-cyan-800 border border-cyan-200 shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-cyan-600" />
                  <span>Landlord Portal</span>
                </button>
                <button
                  onClick={onOpenAddProperty}
                  className="flex items-center space-x-1.5 px-3.5 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>List Property</span>
                </button>
              </>
            )}

            {currentUser.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin-dashboard')}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'admin-dashboard'
                    ? 'bg-cyan-50 text-cyan-800 border border-cyan-200 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Users className="w-4 h-4 text-cyan-600" />
                <span>Admin Console</span>
              </button>
            )}

            {currentUser.role !== 'tenant' && (
              <button
                onClick={() => setActiveTab('wallet')}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'wallet'
                    ? 'bg-cyan-50 text-cyan-800 border border-cyan-200 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Wallet className="w-4 h-4 text-cyan-600" />
                <span>Wallet</span>
                <span className="ml-1 bg-slate-100 text-slate-800 text-[11px] px-2.5 py-0.5 rounded-full border border-slate-300 font-extrabold">
                  KSh {currentUser.walletBalance.toLocaleString()}
                </span>
              </button>
            )}
          </nav>

          {/* User Role Switcher */}
          <div className="flex items-center space-x-3">
            <div className="relative group">
              <div className="flex items-center space-x-2.5 bg-slate-50 hover:bg-slate-100 p-1.5 pr-3 rounded-xl border border-slate-200 cursor-pointer transition-all shadow-xs">
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-lg object-cover border border-cyan-300"
                />
                <div className="text-left hidden sm:block">
                  <p className="text-xs font-bold text-slate-900 leading-tight">
                    {currentUser.name}
                  </p>
                  <p className="text-[10px] text-cyan-700 capitalize font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-600 animate-pulse"></span>
                    {currentUser.role} Account
                  </p>
                </div>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </div>

              {/* User Switcher Dropdown */}
              <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-xl p-2 hidden group-hover:block z-50 animate-in fade-in duration-150">
                <p className="text-[10px] font-bold text-slate-400 px-3 py-1.5 uppercase tracking-wider">
                  Switch Demo Persona
                </p>
                <div className="space-y-1">
                  {users.map((u) => (
                    <button
                      key={u.id}
                      onClick={() => {
                        onSelectUser(u);
                        if (u.role === 'tenant') setActiveTab('tenant-dashboard');
                        else if (u.role === 'landlord') setActiveTab('landlord-dashboard');
                        else if (u.role === 'admin') setActiveTab('admin-dashboard');
                      }}
                      className={`w-full text-left p-2.5 rounded-lg flex items-center space-x-3 transition-colors ${
                        u.id === currentUser.id
                          ? 'bg-cyan-50 border border-cyan-200 text-cyan-900 font-bold'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <img src={u.avatar} alt={u.name} className="w-7 h-7 rounded-md object-cover border border-slate-200" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold truncate text-slate-900">{u.name}</p>
                        <p className="text-[10px] text-slate-500 capitalize">{u.role} &bull; {u.phone}</p>
                      </div>
                      {u.id === currentUser.id && <CheckCircle2 className="w-4 h-4 text-cyan-600 shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Mobile Tab Sub-bar */}
        <div className="md:hidden flex items-center space-x-2 py-2 overflow-x-auto text-xs border-t border-slate-200">
          <button
            onClick={() => setActiveTab('explore')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-bold ${
              activeTab === 'explore' ? 'bg-cyan-600 text-white' : 'text-slate-700 bg-slate-100'
            }`}
          >
            Explore Homes
          </button>
          {currentUser.role === 'tenant' && (
            <button
              onClick={() => setActiveTab('tenant-dashboard')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-bold ${
                activeTab === 'tenant-dashboard' ? 'bg-cyan-600 text-white' : 'text-slate-700 bg-slate-100'
              }`}
            >
              My Rent
            </button>
          )}
          {currentUser.role === 'landlord' && (
            <button
              onClick={() => setActiveTab('landlord-dashboard')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-bold ${
                activeTab === 'landlord-dashboard' ? 'bg-cyan-600 text-white' : 'text-slate-700 bg-slate-100'
              }`}
            >
              Landlord Portal
            </button>
          )}
          {currentUser.role === 'admin' && (
            <button
              onClick={() => setActiveTab('admin-dashboard')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-bold ${
                activeTab === 'admin-dashboard' ? 'bg-cyan-600 text-white' : 'text-slate-700 bg-slate-100'
              }`}
            >
              Admin
            </button>
          )}
          {currentUser.role !== 'tenant' && (
            <button
              onClick={() => setActiveTab('wallet')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-bold ${
                activeTab === 'wallet' ? 'bg-cyan-600 text-white' : 'text-slate-700 bg-slate-100'
              }`}
            >
              Wallet (KSh {currentUser.walletBalance.toLocaleString()})
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
