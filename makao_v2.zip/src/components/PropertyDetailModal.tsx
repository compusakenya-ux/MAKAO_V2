import React, { useState } from 'react';
import { Property, User, LeaseApplication, ApplicationDocument, SourceOfIncomeType } from '../types';
import { X, MapPin, CheckCircle2, MessageSquare, FileText, Send, Building, ShieldCheck, Upload, Trash2 } from 'lucide-react';

interface PropertyDetailModalProps {
  property: Property | null;
  currentUser: User;
  onClose: () => void;
  onSubmitLeaseApplication: (application: LeaseApplication) => void;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({
  property,
  currentUser,
  onClose,
  onSubmitLeaseApplication,
}) => {
  const [selectedUnit, setSelectedUnit] = useState('Unit ' + Math.floor(Math.random() * 80 + 101));
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [appliedSuccess, setAppliedSuccess] = useState(false);

  // Tenant Lease Application Form fields
  const [fullName, setFullName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || 'tenant@example.com');
  const [nationalId, setNationalId] = useState(currentUser?.nationalId || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [sourceOfIncome, setSourceOfIncome] = useState<SourceOfIncomeType>('Employed');
  const [employerName, setEmployerName] = useState('');
  const [employerContactPhone, setEmployerContactPhone] = useState('');

  // Submitted state tracking per property
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Form Fee STK Push Prompt State
  const [showFeePaymentStep, setShowFeePaymentStep] = useState(false);
  const [feeMpesaPhone, setFeeMpesaPhone] = useState(currentUser?.phone || '+254712345678');
  const [feePin, setFeePin] = useState('');
  const [isProcessingFee, setIsProcessingFee] = useState(false);

  // 3 Document Upload Slots
  const [documents, setDocuments] = useState<ApplicationDocument[]>([
    { docType: 'National ID', fileName: '' },
    { docType: 'Payslip/Employer Contract', fileName: '' },
    { docType: 'Face Photo', fileName: '' },
  ]);

  if (!property) return null;

  const handleDocTypeChange = (index: number, newDocType: ApplicationDocument['docType']) => {
    setDocuments((prev) =>
      prev.map((doc, idx) => (idx === index ? { ...doc, docType: newDocType } : doc))
    );
  };

  const handleFileChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDocuments((prev) =>
        prev.map((doc, idx) => (idx === index ? { ...doc, fileName: file.name } : doc))
      );
    }
  };

  const handleRemoveDoc = (index: number) => {
    setDocuments((prev) =>
      prev.map((doc, idx) => (idx === index ? { ...doc, fileName: '' } : doc))
    );
  };

  const handleInitiateSubmission = (e: React.FormEvent) => {
    e.preventDefault();
    setShowFeePaymentStep(true);
  };

  const handleConfirmFeePaymentAndSubmit = () => {
    setIsProcessingFee(true);
    setTimeout(() => {
      setIsProcessingFee(false);
      const validDocs = documents.filter((d) => d.fileName && d.fileName.trim().length > 0);

      const app: LeaseApplication = {
        id: 'app_' + Date.now(),
        propertyId: property.id,
        propertyTitle: property.title,
        unitNumber: selectedUnit,
        tenantId: currentUser.id,
        fullName,
        email,
        nationalId,
        phone,
        emergencyContactName,
        emergencyContactPhone,
        sourceOfIncome,
        employerName,
        employerContactPhone,
        documents: validDocs.length > 0 ? validDocs : [
          { docType: 'National ID', fileName: 'National_ID_Verified.pdf' },
          { docType: 'Face Photo', fileName: 'Selfie_Photo.jpg' }
        ],
        appliedDate: new Date().toISOString().split('T')[0],
        status: 'pending',
      };

      onSubmitLeaseApplication(app);
      setShowFeePaymentStep(false);
      setIsSubmitted(true);
      setAppliedSuccess(true);
      setTimeout(() => {
        setAppliedSuccess(false);
        setShowApplicationForm(false);
        onClose();
      }, 2500);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white text-slate-900 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col">
        
        {/* Gallery Image Header */}
        <div className="relative h-56 sm:h-64 bg-slate-100 shrink-0">
          <img
            src={property.imageUrls[0] || 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800'}
            alt={property.title}
            className="w-full h-full object-cover"
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-white/90 text-slate-800 p-2 rounded-full hover:bg-white transition-colors shadow-md border border-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <div className="bg-white/95 backdrop-blur-md p-3.5 rounded-xl text-slate-900 border border-slate-200 shadow-md">
              <span className="text-xs text-cyan-700 font-extrabold uppercase tracking-wider">{property.city} &bull; {property.type}</span>
              <h2 className="text-lg sm:text-xl font-black text-slate-900">{property.title}</h2>
              <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5 font-medium">
                <MapPin className="w-3.5 h-3.5 text-cyan-600 shrink-0" /> {property.location}
              </p>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-700">
          
          {/* Rent & Deposit Cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <p className="text-xs font-semibold text-slate-500">Monthly Rent</p>
              <p className="text-2xl font-black text-cyan-700 mt-0.5">
                KSh {property.rentPerMonth.toLocaleString()}
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">Due on 5th of every month</p>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <p className="text-xs font-semibold text-slate-500">Refundable Security Deposit</p>
              <p className="text-2xl font-black text-slate-900 mt-0.5">
                KSh {property.depositAmount.toLocaleString()}
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">Held in Makao Escrow</p>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 mb-1.5">Property Overview</h3>
            <p className="text-xs text-slate-600 leading-relaxed font-normal">{property.description}</p>
          </div>

          {/* Amenities */}
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 mb-2">Included Amenities & Services</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {property.amenities.map((amenity, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-slate-50 border border-slate-200 p-2 rounded-lg text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-cyan-600 shrink-0" />
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Landlord Contact Info - Unlocked ONLY after Application Submission */}
          {(appliedSuccess || isSubmitted) ? (
            <div className="bg-emerald-950 text-white p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm border border-emerald-800 animate-in fade-in">
              <div className="space-y-0.5 text-center sm:text-left">
                <div className="flex items-center gap-1.5 justify-center sm:justify-start">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <p className="text-[10px] text-emerald-300 font-extrabold uppercase tracking-wider">Application Sent &amp; Landlord Unlocked</p>
                </div>
                <p className="text-sm font-extrabold text-white">{property.landlordName}</p>
                <p className="text-xs font-mono text-emerald-200">{property.landlordPhone}</p>
              </div>
              <a
                href={`https://wa.me/${property.landlordPhone.replace(/\+/g, '')}?text=Hello%20${encodeURIComponent(property.landlordName)},%20I%20have%20submitted%20my%20lease%20application%20for%20${encodeURIComponent(property.title)}.`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all shrink-0"
              >
                <MessageSquare className="w-4 h-4 fill-slate-950" />
                <span>WhatsApp Landlord</span>
              </a>
            </div>
          ) : (
            <div className="bg-slate-100 border border-slate-200 p-3.5 rounded-2xl flex items-center justify-between gap-3 text-xs text-slate-700">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-cyan-600 shrink-0" />
                <div>
                  <p className="font-extrabold text-slate-900">Direct Landlord Contact Protected</p>
                  <p className="text-[11px] text-slate-500">
                    "WhatsApp Landlord" and direct contact details will be automatically unlocked after you fill out and submit the application form below.
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-extrabold text-slate-500 bg-slate-200 px-2.5 py-1 rounded-lg uppercase tracking-wider shrink-0">
                Locked
              </span>
            </div>
          )}

          {/* Tenant Lease Application Form Section */}
          <div className="border-t border-slate-200 pt-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-cyan-600" />
                  Tenant Lease Application Form
                </h3>
                <p className="text-xs text-slate-500">
                  Submit your details directly to the landlord for unit screening.
                </p>
              </div>

              {!showApplicationForm && (
                <button
                  type="button"
                  onClick={() => setShowApplicationForm(true)}
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl text-xs shadow-sm transition-all"
                >
                  Fill Application Form
                </button>
              )}
            </div>

            {/* Application Form */}
            {showApplicationForm && (
              <form onSubmit={handleInitiateSubmission} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4 text-xs">
                
                {appliedSuccess ? (
                  <div className="py-6 text-center space-y-2">
                    <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle2 className="w-7 h-7" />
                    </div>
                    <h4 className="text-base font-extrabold text-slate-900">Application Submitted!</h4>
                    <p className="text-xs text-slate-600 max-w-sm mx-auto">
                      Your lease application for <strong>{property.title} ({selectedUnit})</strong> has been verified & sent to <strong>{property.landlordName}</strong>. Form fee of KSh 200 deposited to Admin Account.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Unit Number</label>
                        <input
                          type="text"
                          required
                          value={selectedUnit}
                          onChange={(e) => setSelectedUnit(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. John Kamau"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                        <input
                          type="email"
                          required
                          placeholder="e.g. john.kamau@example.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Kenyan National ID Number</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. 12345678"
                          value={nationalId}
                          onChange={(e) => setNationalId(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Telephone Number</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. +254712345678"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>
                    </div>

                    {/* Separate Emergency Contact Fields */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Emergency Contact Full Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Peter Kamau (Brother)"
                          value={emergencyContactName}
                          onChange={(e) => setEmergencyContactName(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Emergency Contact Tel. Number</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. +254720112233"
                          value={emergencyContactPhone}
                          onChange={(e) => setEmergencyContactPhone(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Source of Income</label>
                        <select
                          value={sourceOfIncome}
                          onChange={(e: any) => setSourceOfIncome(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-cyan-600"
                        >
                          <option value="Employed">Employed</option>
                          <option value="Business">Business</option>
                          <option value="Student">Student</option>
                          <option value="University/College">University/College</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Employer / Business / University Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Kenya Commercial Bank or University of Nairobi"
                          value={employerName}
                          onChange={(e) => setEmployerName(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">Employer / Contact Tel.</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. +254722000000"
                          value={employerContactPhone}
                          onChange={(e) => setEmployerContactPhone(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-medium text-slate-900 focus:outline-none focus:border-cyan-600"
                        />
                      </div>
                    </div>

                    {/* 3 Evidence Document Upload Slots with Dropdowns */}
                    <div className="space-y-2 pt-3 border-t border-slate-200">
                      <div className="flex items-center justify-between">
                        <label className="block font-extrabold text-slate-900 text-xs">
                          Evidence Document Uploads (Up to 3 Files)
                        </label>
                        <span className="text-[10px] text-cyan-800 bg-cyan-50 border border-cyan-200 px-2 py-0.5 rounded font-extrabold">
                          JPG / PNG / PDF
                        </span>
                      </div>

                      <div className="space-y-2.5">
                        {documents.map((doc, slotIdx) => (
                          <div key={slotIdx} className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                            <div className="sm:w-1/2">
                              <label className="block text-[10px] font-bold text-slate-500 mb-1">
                                Document {slotIdx + 1} Type
                              </label>
                              <select
                                value={doc.docType}
                                onChange={(e) => handleDocTypeChange(slotIdx, e.target.value as any)}
                                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-cyan-600"
                              >
                                <option value="National ID">National ID</option>
                                <option value="Campus ID">Campus ID</option>
                                <option value="Payslip/Employer Contract">Payslip/Employer Contract</option>
                                <option value="Face Photo">Face Photo</option>
                              </select>
                            </div>

                            <div className="flex-1">
                              <label className="block text-[10px] font-bold text-slate-500 mb-1">
                                Attachment (.jpg, .pdf)
                              </label>
                              <div className="flex items-center gap-2">
                                <label
                                  htmlFor={`doc-upload-${slotIdx}`}
                                  className="flex-1 flex items-center justify-between bg-slate-50 border border-dashed border-slate-300 hover:border-cyan-500 rounded-lg px-3 py-1.5 cursor-pointer text-xs transition-colors"
                                >
                                  <span className="truncate text-slate-700 font-mono text-[11px]">
                                    {doc.fileName ? doc.fileName : 'Select jpg/pdf evidence...'}
                                  </span>
                                  <span className="text-[10px] font-bold text-cyan-700 bg-cyan-100 px-2 py-0.5 rounded shrink-0 ml-2">
                                    {doc.fileName ? 'Selected' : 'Browse'}
                                  </span>
                                </label>
                                <input
                                  type="file"
                                  accept=".jpg,.jpeg,.png,.pdf"
                                  onChange={(e) => handleFileChange(slotIdx, e)}
                                  className="hidden"
                                  id={`doc-upload-${slotIdx}`}
                                />
                                {doc.fileName && (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveDoc(slotIdx)}
                                    className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-slate-100"
                                    title="Remove document"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setShowApplicationForm(false)}
                        className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl text-xs shadow-sm transition-all flex items-center gap-2"
                      >
                        <Send className="w-4 h-4" />
                        <span>Submit Lease Application</span>
                      </button>
                    </div>
                  </>
                )}

              </form>
            )}
          </div>

        </div>

      </div>

      {/* Form Submission Fee 200 KES Payment Modal Overlay */}
      {showFeePaymentStep && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl border border-slate-200 relative text-slate-900">
            <button
              onClick={() => setShowFeePaymentStep(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="w-10 h-10 bg-cyan-100 text-cyan-700 rounded-xl flex items-center justify-center font-black">
                200
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Lease Application Form Fee</h3>
                <p className="text-xs text-slate-500 font-medium">M-Pesa Direct Processing Payment</p>
              </div>
            </div>

            {/* Non-Refundable Disclaimer Banner */}
            <div className="bg-amber-50 border-2 border-amber-300/80 rounded-xl p-3.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-amber-900 uppercase tracking-wide">
                  ⚠️ Disclaimer & Notice
                </span>
                <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded shadow-xs uppercase">
                  Non-Refundable
                </span>
              </div>
              <p className="text-xs text-amber-950 font-bold leading-snug">
                Form Submission Fee: <strong>KSh 200 (Non-Refundable)</strong>
              </p>
              <p className="text-[11px] text-amber-800 font-medium">
                This fee will be deposited directly to the <strong>Makao System Admin Account</strong> for identity background checks and document verification (not paid to the landlord).
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Fee Amount:</span>
                <span className="font-black text-slate-900">KSh 200</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Destination:</span>
                <span className="font-extrabold text-cyan-800 bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200">
                  System Admin Account
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Refund Policy:</span>
                <span className="font-black text-red-600">Strictly Non-Refundable</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  M-Pesa Mobile Number
                </label>
                <input
                  type="text"
                  value={feeMpesaPhone}
                  onChange={(e) => setFeeMpesaPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-cyan-600"
                  placeholder="+2547XXXXXXXX"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold text-slate-700 mb-1">
                  M-Pesa PIN (Simulated Prompt)
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={feePin}
                  onChange={(e) => setFeePin(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-center text-lg tracking-widest text-slate-900 focus:outline-none focus:border-cyan-600"
                  placeholder="••••"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowFeePaymentStep(false)}
                disabled={isProcessingFee}
                className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmFeePaymentAndSubmit}
                disabled={isProcessingFee}
                className="px-5 py-2.5 bg-gradient-to-r from-cyan-600 to-teal-700 hover:from-cyan-700 hover:to-teal-800 text-white font-extrabold rounded-xl text-xs shadow-md transition-all flex items-center gap-2"
              >
                {isProcessingFee ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Processing KSh 200 STK...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Pay KSh 200 Fee & Submit</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
