import React, { useState } from 'react';
import { Property, PropertyType, User } from '../types';
import { X, Building2, Plus } from 'lucide-react';

interface AddPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onAddProperty: (property: Property) => void;
}

export const AddPropertyModal: React.FC<AddPropertyModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onAddProperty,
}) => {
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [city, setCity] = useState<'Nairobi' | 'Mombasa' | 'Kisumu' | 'Eldoret' | 'Nakuru' | 'Kisii' | 'Thika'>('Nairobi');
  const [type, setType] = useState<PropertyType>('2 Bedroom Apartment');
  const [rent, setRent] = useState(35000);
  const [deposit, setDeposit] = useState(35000);
  const [bedrooms, setBedrooms] = useState(2);
  const [bathrooms, setBathrooms] = useState(1);
  const [units, setUnits] = useState(8);
  const [amenitiesInput, setAmenitiesInput] = useState('24/7 Security, Borehole Water, High-Speed Wifi, Parking');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amenities = amenitiesInput.split(',').map((a) => a.trim()).filter(Boolean);
    const newProperty: Property = {
      id: 'prop_' + Date.now(),
      title,
      location,
      city,
      type,
      rentPerMonth: Number(rent),
      depositAmount: Number(deposit),
      bedrooms: Number(bedrooms),
      bathrooms: Number(bathrooms),
      amenities,
      imageUrls: [imageUrl],
      landlordId: currentUser.id,
      landlordName: currentUser.name,
      landlordPhone: currentUser.phone,
      availableUnits: Number(units),
      totalUnits: Number(units),
      description: description || `Modern ${type} in ${location}, ${city}. Includes top amenities and M-Pesa automated rent collection.`,
      featured: true,
    };
    onAddProperty(newProperty);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white text-slate-900 rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-200 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <Building2 className="w-6 h-6 text-cyan-400" />
            <div>
              <h3 className="font-bold text-base text-white">List New Rental Property</h3>
              <p className="text-xs text-slate-300">Add property details & configure automated rent collection</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs flex-1">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Property Title / Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Lavington Palms 2 Bedroom Apartment"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-cyan-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">City / Region</label>
              <select
                value={city}
                onChange={(e: any) => setCity(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:outline-none focus:border-cyan-600"
              >
                <option value="Nairobi">Nairobi</option>
                <option value="Mombasa">Mombasa</option>
                <option value="Kisumu">Kisumu</option>
                <option value="Eldoret">Eldoret</option>
                <option value="Nakuru">Nakuru</option>
                <option value="Kisii">Kisii</option>
                <option value="Thika">Thika</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Property Category</label>
              <select
                value={type}
                onChange={(e: any) => setType(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:outline-none focus:border-cyan-600"
              >
                <option value="1 Bedroom Apartment">1 Bedroom Apartment</option>
                <option value="2 Bedroom Apartment">2 Bedroom Apartment</option>
                <option value="3 Bedroom Apartment">3 Bedroom Apartment</option>
                <option value="Studio">Studio</option>
                <option value="Bedsitter">Bedsitter</option>
                <option value="Single Room">Single Room</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Specific Location / Street Address</label>
            <input
              type="text"
              required
              placeholder="e.g. Lavington, James Gichuru Road"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-cyan-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Monthly Rent (KSh)</label>
              <input
                type="number"
                required
                value={rent}
                onChange={(e) => setRent(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-cyan-700 focus:outline-none focus:border-cyan-600"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Security Deposit (KSh)</label>
              <input
                type="number"
                required
                value={deposit}
                onChange={(e) => setDeposit(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-cyan-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Bedrooms</label>
              <input
                type="number"
                value={bedrooms}
                onChange={(e) => setBedrooms(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Bathrooms</label>
              <input
                type="number"
                value={bathrooms}
                onChange={(e) => setBathrooms(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Total Units</label>
              <input
                type="number"
                value={units}
                onChange={(e) => setUnits(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Photo Image URL</label>
            <input
              type="text"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Amenities (Comma separated)</label>
            <input
              type="text"
              value={amenitiesInput}
              onChange={(e) => setAmenitiesInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe house features, water availability, security..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-cyan-600 hover:bg-cyan-700 text-white font-extrabold rounded-xl text-sm shadow-sm transition-all flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>Publish Property Listing</span>
          </button>
        </form>

      </div>
    </div>
  );
};
