import React from 'react';
import { X, Printer, ShieldCheck, CheckCircle } from 'lucide-react';
import { Payment } from '../types';

interface ReceiptModalProps {
  payment: Payment | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ payment, onClose }) => {
  if (!payment) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white text-slate-900 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200">
        
        {/* Top bar controls */}
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between no-print">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-cyan-400" />
            <span className="font-extrabold text-sm">Official Rent Payment Receipt</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-700 text-white rounded-lg text-xs font-bold"
            >
              <Printer className="w-4 h-4" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper */}
        <div id="printable-receipt" className="p-8 space-y-6 bg-white border-t-4 border-cyan-600 text-slate-900">
          
          {/* Header & Logo */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-cyan-600 text-white font-black flex items-center justify-center text-lg shadow-sm">
                  M
                </div>
                <span className="font-black text-2xl tracking-tight text-slate-900">MAKAO</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 font-bold">
                Makao - A Sena Global Limited Company &bull; Nairobi, Kenya
              </p>
              <p className="text-[11px] text-slate-500 font-mono">KRA PIN: P051988273X &bull; Support: +254 700 000 000</p>
            </div>
            <div className="text-right">
              <span className="inline-block bg-cyan-100 text-cyan-900 border border-cyan-200 text-xs font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider mb-1">
                {payment.status}
              </span>
              <p className="text-xs text-slate-600 font-mono">Receipt #: <strong className="text-slate-900">{payment.mpesaReceiptNumber}</strong></p>
              <p className="text-xs text-slate-600 font-mono">Date: {payment.date}</p>
            </div>
          </div>

          {/* Key Payment Summary Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-center">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Rent Paid</p>
            <p className="text-3xl font-black text-cyan-700 mt-1">
              KSh {payment.amount.toLocaleString()}
            </p>
            <p className="text-xs text-slate-700 font-bold mt-1">
              For Period: {payment.month} {payment.year} Rent
            </p>
          </div>

          {/* Details Table */}
          <div className="space-y-3 text-xs">
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500 font-medium">Tenant Name</span>
              <span className="font-extrabold text-slate-900">{payment.tenantName}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500 font-medium">Property Name</span>
              <span className="font-extrabold text-slate-900">{payment.propertyTitle}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500 font-medium">Unit / Apartment No.</span>
              <span className="font-extrabold text-slate-900">{payment.unitNumber}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500 font-medium">Payment Gateway</span>
              <span className="font-extrabold text-slate-900">{payment.method} ({payment.phoneNumber})</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500 font-medium">Rent Status</span>
              <span className="font-extrabold text-cyan-700 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-cyan-600" /> Settled On Time
              </span>
            </div>
          </div>

          {/* Stamp & Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            <div className="border-2 border-dashed border-cyan-600 p-2 rounded-lg text-center transform -rotate-2">
              <p className="text-[10px] font-extrabold text-cyan-700 tracking-wider uppercase">MAKAO VERIFIED</p>
              <p className="text-[9px] text-slate-500 font-mono">AUTOMATED PAYMENT LEDGER</p>
            </div>
            <div className="text-right text-[10px] text-slate-500 font-medium">
              <p>Computer-generated official receipt.</p>
              <p>Valid without physical signature.</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
