import React from 'react';

interface MakaoLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const MakaoLogo: React.FC<MakaoLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const sizeMap = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const textSizeMap = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Sena / Makao "S" Faceted Logo Icon */}
      <div className={`${sizeMap[size]} relative rounded-2xl bg-gradient-to-br from-teal-500 via-cyan-600 to-emerald-700 p-1.5 shadow-md flex items-center justify-center overflow-hidden border border-cyan-300/40 shrink-0`}>
        {/* Glossy top overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-black/20 pointer-events-none" />
        
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-sm"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="facetTop" x1="20" y1="20" x2="80" y2="40" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
              <stop offset="50%" stopColor="#A5F3FC" />
              <stop offset="100%" stopColor="#0891B2" />
            </linearGradient>
            <linearGradient id="facetMid" x1="20" y1="50" x2="80" y2="50" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#2DD4BF" />
              <stop offset="100%" stopColor="#0F766E" />
            </linearGradient>
            <linearGradient id="facetBottom" x1="20" y1="60" x2="80" y2="90" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#CCFBF1" />
              <stop offset="50%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>
            <linearGradient id="facetShadow" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#134E4A" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#064E3B" stopOpacity="0.8" />
            </linearGradient>
          </defs>

          {/* Faceted 3D 'S' Polygon Layers matching Sena Logo */}
          {/* Top fold */}
          <polygon points="35,22 75,22 82,34 50,48 28,34" fill="url(#facetTop)" />
          <polygon points="28,34 50,48 20,62 12,48" fill="url(#facetShadow)" />
          
          {/* Middle connector fold */}
          <polygon points="50,48 82,34 88,48 58,64" fill="url(#facetMid)" />
          
          {/* Bottom fold */}
          <polygon points="58,64 88,48 72,78 25,78 18,66" fill="url(#facetBottom)" />
          <polygon points="25,78 72,78 52,90 12,90" fill="url(#facetTop)" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 leading-none">
            <span className={`${textSizeMap[size]} font-black tracking-tight text-slate-900 uppercase`}>
              MAKAO
            </span>
            <span className="bg-cyan-700 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded tracking-wide uppercase">
              SENA
            </span>
          </div>
          <span className="text-[10px] text-cyan-800 font-extrabold tracking-tight mt-0.5">
            A Sena Global Limited Company
          </span>
        </div>
      )}
    </div>
  );
};
