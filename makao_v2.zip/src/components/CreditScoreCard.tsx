import React from 'react';
import { CreditScore } from '../types';
import { ShieldCheck, Award, CheckCircle2, Clock, Calendar } from 'lucide-react';

interface CreditScoreCardProps {
  creditScore: CreditScore;
  onOpenCertificate: () => void;
}

export const CreditScoreCard: React.FC<CreditScoreCardProps> = ({
  creditScore,
  onOpenCertificate,
}) => {
  // Score is out of 500 max in Makao platform algorithm
  const percentage = Math.min(100, Math.max(0, (creditScore.score / 500) * 100));

  const getRatingColor = (rating: string) => {
    switch (rating) {
      case 'Excellent':
        return 'text-cyan-300 bg-cyan-950/80 border-cyan-800 shadow-[0_0_10px_rgba(6,182,212,0.2)]';
      case 'Good':
        return 'text-sky-300 bg-sky-950/80 border-sky-800';
      case 'Fair':
        return 'text-amber-300 bg-amber-950/80 border-amber-800';
      default:
        return 'text-rose-300 bg-rose-950/80 border-rose-800';
    }
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
      
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-cyan-500/40 flex items-center justify-center text-white shadow-[0_0_15px_rgba(6,182,212,0.25)]">
            <ShieldCheck className="w-7 h-7 text-cyan-400" />
          </div>
          <div>
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">KENYA MAKAO BUREAU</span>
            <h2 className="text-lg font-black text-white">Rent Credit Score Engine</h2>
          </div>
        </div>

        <button
          onClick={onOpenCertificate}
          className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-950 hover:bg-slate-800 text-cyan-300 text-xs font-bold rounded-xl shadow-[0_0_12px_rgba(6,182,212,0.2)] transition-all border border-cyan-500/40"
        >
          <Award className="w-4 h-4 text-amber-300" />
          <span>Generate Official Certificate</span>
        </button>
      </div>

      {/* Main Score Display Box */}
      <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        
        {/* Score Radial Visual */}
        <div className="flex flex-col items-center justify-center text-center space-y-2 md:border-r border-slate-800 md:pr-6">
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* SVG Progress Circle */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-800"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-cyan-400 stroke-current transition-all duration-1000 ease-out"
                strokeDasharray={`${percentage}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-black text-white tracking-tight">{creditScore.score}</span>
              <span className="text-[10px] text-slate-400 font-semibold uppercase">out of 500</span>
            </div>
          </div>

          <div className={`px-3 py-1 rounded-full text-xs font-extrabold border ${getRatingColor(creditScore.rating)}`}>
            {creditScore.rating} Rating
          </div>
        </div>

        {/* Quick Statistics Grid */}
        <div className="md:col-span-2 grid grid-cols-2 gap-4">
          <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
            <p className="text-[11px] text-slate-400 font-medium">On-Time Rent Payments</p>
            <p className="text-2xl font-black text-cyan-400 mt-0.5">
              {creditScore.onTimePayments} <span className="text-xs text-slate-400 font-normal">/ {creditScore.totalPayments}</span>
            </p>
            <p className="text-[10px] text-cyan-300 mt-1 flex items-center gap-1 font-semibold">
              <CheckCircle2 className="w-3 h-3 text-cyan-400" />
              {((creditScore.onTimePayments / creditScore.totalPayments) * 100).toFixed(0)}% On-time track record
            </p>
          </div>

          <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
            <p className="text-[11px] text-slate-400 font-medium">Late Payment Incidents</p>
            <p className="text-2xl font-black text-amber-400 mt-0.5">
              {creditScore.latePayments} <span className="text-xs text-slate-400 font-normal">times</span>
            </p>
            <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-400" />
              Total days late: {creditScore.totalDaysLate} days
            </p>
          </div>

          <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
            <p className="text-[11px] text-slate-400 font-medium">Monthly Score Reward</p>
            <p className="text-lg font-bold text-cyan-400 mt-0.5">+10 Points</p>
            <p className="text-[10px] text-slate-400">Awarded for M-Pesa rent before 5th</p>
          </div>

          <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
            <p className="text-[11px] text-slate-400 font-medium">Late Penalty Rule</p>
            <p className="text-lg font-bold text-rose-400 mt-0.5">-5 Points / Day</p>
            <p className="text-[10px] text-slate-400">Deducted for rent delayed past due date</p>
          </div>
        </div>

      </div>

      {/* Credit History Ledger */}
      <div>
        <h3 className="text-sm font-bold text-slate-200 mb-3 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-cyan-400" />
          Recent Rent Payment Audit History
        </h3>

        <div className="space-y-2">
          {creditScore.history.map((event) => (
            <div
              key={event.id}
              className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between text-xs"
            >
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${event.status === 'On Time' ? 'bg-slate-900 text-cyan-400 border border-cyan-500/30' : 'bg-rose-950 text-rose-400 border border-rose-800'}`}>
                  {event.status === 'On Time' ? <CheckCircle2 className="w-4 h-4 text-cyan-400" /> : <Clock className="w-4 h-4" />}
                </div>
                <div>
                  <p className="font-bold text-white">{event.month} {event.year} Rent</p>
                  <p className="text-[11px] text-slate-400">M-Pesa Receipt: {event.receiptNumber} &bull; {event.date}</p>
                </div>
              </div>

              <div className="text-right">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  event.status === 'On Time' ? 'bg-slate-900 text-cyan-300 border border-cyan-500/30' : 'bg-rose-950 text-rose-300 border border-rose-800'
                }`}>
                  {event.status}
                </span>
                <p className="text-xs font-black text-white mt-0.5">
                  KSh {event.amount.toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
