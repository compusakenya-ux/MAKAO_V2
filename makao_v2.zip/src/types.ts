export type UserRole = 'tenant' | 'landlord' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  nationalId: string;
  avatar?: string;
  walletBalance: number;
}

export type PropertyType =
  | 'Studio'
  | 'Single Room'
  | 'Bedsitter'
  | '1 Bedroom Apartment'
  | '2 Bedroom Apartment'
  | '3 Bedroom Apartment';

export interface Property {
  id: string;
  title: string;
  location: string;
  city: 'Nairobi' | 'Mombasa' | 'Kisumu' | 'Eldoret' | 'Nakuru' | 'Kisii' | 'Thika';
  type: PropertyType;
  rentPerMonth: number;
  depositAmount: number;
  bedrooms: number;
  bathrooms: number;
  amenities: string[];
  imageUrls: string[];
  landlordId: string;
  landlordName: string;
  landlordPhone: string;
  availableUnits: number;
  totalUnits: number;
  description: string;
  featured?: boolean;
}

export interface Lease {
  id: string;
  tenantId: string;
  landlordId: string;
  propertyId: string;
  propertyTitle: string;
  unitNumber: string;
  rentAmount: number;
  depositAmount: number;
  startDate: string;
  dueDateDay: number; // e.g., 5th of every month
  status: 'active' | 'pending' | 'terminated';
  paymentStatusForCurrentMonth: 'paid' | 'due' | 'overdue';
}

export type SourceOfIncomeType = 'Employed' | 'Business' | 'Student' | 'University/College';

export interface ApplicationDocument {
  docType: 'National ID' | 'Campus ID' | 'Payslip/Employer Contract' | 'Face Photo';
  fileName: string;
  fileUrl?: string;
}

export interface LeaseApplication {
  id: string;
  propertyId: string;
  propertyTitle: string;
  unitNumber: string;
  tenantId: string;
  fullName: string;
  email: string;
  nationalId: string;
  phone: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  sourceOfIncome: SourceOfIncomeType;
  employerName: string;
  employerContactPhone: string;
  documents?: ApplicationDocument[];
  appliedDate: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Payment {
  id: string;
  leaseId: string;
  tenantId: string;
  tenantName: string;
  propertyTitle: string;
  unitNumber: string;
  amount: number;
  date: string;
  method: 'M-Pesa' | 'Bank Transfer';
  mpesaReceiptNumber: string;
  phoneNumber: string;
  status: 'completed' | 'pending' | 'failed';
  month: string;
  year: number;
}

export interface CreditEvent {
  id: string;
  month: string;
  year: number;
  daysLate: number;
  pointsDeducted: number;
  status: 'On Time' | 'Late' | 'Defaulted';
  amount: number;
  receiptNumber: string;
  date: string;
}

export interface CreditScore {
  tenantId: string;
  nationalId: string;
  fullName: string;
  score: number; // 100 - 500
  totalPayments: number;
  onTimePayments: number;
  latePayments: number;
  totalDaysLate: number;
  rating: 'Excellent' | 'Good' | 'Fair' | 'Poor' | 'Critical';
  history: CreditEvent[];
  lastUpdated: string;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'topup' | 'rent_payment' | 'withdrawal' | 'refund' | 'payout';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
  referenceCode: string;
  paymentMethod: string;
}
