import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { MpesaModal } from './components/MpesaModal';
import { ReceiptModal } from './components/ReceiptModal';
import { PropertyDetailModal } from './components/PropertyDetailModal';
import { AddPropertyModal } from './components/AddPropertyModal';
import { MakaoLogo } from './components/MakaoLogo';

import { PropertyExplorer } from './views/PropertyExplorer';
import { TenantDashboard } from './views/TenantDashboard';
import { LandlordDashboard } from './views/LandlordDashboard';
import { AdminDashboard } from './views/AdminDashboard';
import { WalletView } from './views/WalletView';

import {
  INITIAL_USERS,
  INITIAL_PROPERTIES,
  INITIAL_LEASES,
  INITIAL_LEASE_APPLICATIONS,
  INITIAL_PAYMENTS,
  INITIAL_CREDIT_SCORE,
  INITIAL_WALLET_TRANSACTIONS,
} from './data/mockData';

import { User, Property, Lease, Payment, CreditScore, WalletTransaction, LeaseApplication } from './types';

export function App() {
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]); // John Kamau (Tenant) by default
  const [activeTab, setActiveTab] = useState<string>('explore');

  const [properties, setProperties] = useState<Property[]>(INITIAL_PROPERTIES);
  const [leases, setLeases] = useState<Lease[]>(INITIAL_LEASES);
  const [leaseApplications, setLeaseApplications] = useState<LeaseApplication[]>(INITIAL_LEASE_APPLICATIONS);
  const [payments, setPayments] = useState<Payment[]>(INITIAL_PAYMENTS);
  const [creditScore, setCreditScore] = useState<CreditScore>(INITIAL_CREDIT_SCORE);
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(INITIAL_WALLET_TRANSACTIONS);

  // Modal States
  const [isMpesaOpen, setIsMpesaOpen] = useState(false);
  const [mpesaAmount, setMpesaAmount] = useState(45000);

  const [selectedReceiptPayment, setSelectedReceiptPayment] = useState<Payment | null>(null);

  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [isAddPropertyOpen, setIsAddPropertyOpen] = useState(false);

  // Active lease for tenant
  const tenantLease = leases.find((l) => l.tenantId === currentUser.id) || null;

  const handleSelectUser = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'tenant' && activeTab === 'wallet') {
      setActiveTab('tenant-dashboard');
    }
  };

  // Handle M-Pesa Payment Success
  const handlePaymentSuccess = (payment: Payment) => {
    setPayments((prev) => [payment, ...prev]);

    // Update lease status
    setLeases((prev) =>
      prev.map((l) =>
        l.id === payment.leaseId ? { ...l, paymentStatusForCurrentMonth: 'paid' } : l
      )
    );

    // Update tenant credit score (+10 points for on-time payment)
    setCreditScore((prev) => ({
      ...prev,
      score: Math.min(500, prev.score + 10),
      totalPayments: prev.totalPayments + 1,
      onTimePayments: prev.onTimePayments + 1,
      history: [
        {
          id: 'ce_' + Date.now(),
          month: payment.month,
          year: payment.year,
          daysLate: 0,
          pointsDeducted: 0,
          status: 'On Time',
          amount: payment.amount,
          receiptNumber: payment.mpesaReceiptNumber,
          date: new Date().toISOString().split('T')[0],
        },
        ...prev.history,
      ],
    }));

    // Log wallet transaction
    const wt: WalletTransaction = {
      id: 'wt_' + Date.now(),
      userId: currentUser.id,
      type: 'rent_payment',
      amount: payment.amount,
      description: `Rent payment for ${payment.propertyTitle} (${payment.unitNumber})`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'completed',
      referenceCode: payment.mpesaReceiptNumber,
      paymentMethod: 'M-Pesa Express',
    };
    setWalletTransactions((prev) => [wt, ...prev]);
  };

  // Wallet Top-up
  const handleWalletTopUp = (amount: number, phone: string) => {
    setCurrentUser((prev) => ({ ...prev, walletBalance: prev.walletBalance + amount }));
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, walletBalance: u.walletBalance + amount } : u))
    );

    const wt: WalletTransaction = {
      id: 'wt_' + Date.now(),
      userId: currentUser.id,
      type: 'topup',
      amount: amount,
      description: `M-Pesa STK Top Up (${phone})`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'completed',
      referenceCode: 'TOP' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      paymentMethod: 'M-Pesa',
    };
    setWalletTransactions((prev) => [wt, ...prev]);
  };

  // Wallet Withdraw
  const handleWalletWithdraw = (amount: number, phone: string) => {
    if (currentUser.walletBalance < amount) return;

    setCurrentUser((prev) => ({ ...prev, walletBalance: prev.walletBalance - amount }));
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, walletBalance: u.walletBalance - amount } : u))
    );

    const wt: WalletTransaction = {
      id: 'wt_' + Date.now(),
      userId: currentUser.id,
      type: 'withdrawal',
      amount: amount,
      description: `M-Pesa B2C Withdrawal to ${phone}`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'completed',
      referenceCode: 'WTH' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      paymentMethod: 'M-Pesa B2C',
    };
    setWalletTransactions((prev) => [wt, ...prev]);
  };

  // Add Property
  const handleAddProperty = (property: Property) => {
    setProperties((prev) => [property, ...prev]);
  };

  // Submit Tenant Lease Application
  const handleSubmitLeaseApplication = (app: LeaseApplication) => {
    setLeaseApplications((prev) => [app, ...prev]);

    // Also auto-create a lease record for the tenant
    const propertyObj = properties.find((p) => p.id === app.propertyId);
    if (propertyObj) {
      const newLease: Lease = {
        id: 'lease_' + Date.now(),
        tenantId: app.tenantId,
        landlordId: propertyObj.landlordId,
        propertyId: propertyObj.id,
        propertyTitle: propertyObj.title,
        unitNumber: app.unitNumber,
        rentAmount: propertyObj.rentPerMonth,
        depositAmount: propertyObj.depositAmount,
        startDate: new Date().toISOString().split('T')[0],
        dueDateDay: 5,
        status: 'active',
        paymentStatusForCurrentMonth: 'due',
      };
      setLeases((prev) => [newLease, ...prev]);

      // Reduce vacant unit count
      setProperties((prev) =>
        prev.map((p) =>
          p.id === propertyObj.id ? { ...p, availableUnits: Math.max(0, p.availableUnits - 1) } : p
        )
      );
    }
  };

  // Send WhatsApp Reminder
  const handleSendWhatsappReminder = (
    phone: string,
    name: string,
    amount: number,
    unit: string
  ) => {
    const cleanPhone = phone.replace(/\+/g, '');
    const msg = `Hello ${name}, this is a rent reminder for Unit ${unit}. Your monthly rent of KSh ${amount.toLocaleString()} is due. Please pay via Makao M-Pesa Paybill 889900 Account ${unit}. Thank you!`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Navigation Header */}
      <Navbar
        currentUser={currentUser}
        users={users}
        onSelectUser={handleSelectUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddProperty={() => setIsAddPropertyOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'explore' && (
          <PropertyExplorer
            properties={properties}
            currentUser={currentUser}
            onSelectProperty={setSelectedProperty}
          />
        )}

        {activeTab === 'tenant-dashboard' && (
          <TenantDashboard
            tenant={currentUser}
            lease={tenantLease}
            payments={payments}
            creditScore={creditScore}
            onOpenMpesaModal={(amt) => {
              setMpesaAmount(amt);
              setIsMpesaOpen(true);
            }}
            onOpenReceipt={setSelectedReceiptPayment}
          />
        )}

        {activeTab === 'landlord-dashboard' && (
          <LandlordDashboard
            landlord={currentUser}
            properties={properties}
            leases={leases}
            payments={payments}
            leaseApplications={leaseApplications}
            onOpenAddProperty={() => setIsAddPropertyOpen(true)}
            onSendWhatsappReminder={handleSendWhatsappReminder}
          />
        )}

        {activeTab === 'admin-dashboard' && (
          <AdminDashboard
            users={users}
            properties={properties}
            payments={payments}
            creditScore={creditScore}
          />
        )}

        {activeTab === 'wallet' && (
          <WalletView
            user={currentUser}
            transactions={walletTransactions}
            onTopUp={handleWalletTopUp}
            onWithdraw={handleWalletWithdraw}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white text-slate-600 border-t border-slate-200 text-xs py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div className="flex items-center space-x-3">
            <MakaoLogo size="sm" showText={true} />
          </div>

          <div className="flex flex-col items-center space-y-1">
            <p className="font-extrabold text-slate-800 text-xs text-center">
              AI Integration, M-Pesa Convenience and fastest Customer response time
            </p>
            <p className="text-[11px] font-semibold text-slate-500">
              Nairobi &bull; Mombasa &bull; Kisumu &bull; Eldoret &bull; All 47 Counties
            </p>
          </div>

          <p className="text-[11px] text-slate-500 font-extrabold text-center md:text-right">
            &copy; {new Date().getFullYear()} Makao - A Sena Global Limited Company. All rights reserved.
          </p>
        </div>
      </footer>

      {/* Modals */}
      <MpesaModal
        isOpen={isMpesaOpen}
        onClose={() => setIsMpesaOpen(false)}
        amount={mpesaAmount}
        phone={currentUser.phone}
        leaseInfo={
          tenantLease
            ? {
                propertyTitle: tenantLease.propertyTitle,
                unitNumber: tenantLease.unitNumber,
                leaseId: tenantLease.id,
                tenantName: currentUser.name,
              }
            : undefined
        }
        onSuccess={handlePaymentSuccess}
      />

      <ReceiptModal
        payment={selectedReceiptPayment}
        onClose={() => setSelectedReceiptPayment(null)}
      />

      <PropertyDetailModal
        property={selectedProperty}
        currentUser={currentUser}
        onClose={() => setSelectedProperty(null)}
        onSubmitLeaseApplication={handleSubmitLeaseApplication}
      />

      <AddPropertyModal
        isOpen={isAddPropertyOpen}
        onClose={() => setIsAddPropertyOpen(false)}
        currentUser={currentUser}
        onAddProperty={handleAddProperty}
      />
    </div>
  );
}

export default App;
