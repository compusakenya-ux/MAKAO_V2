const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const cron = require('node-cron');

// Load env
dotenv.config();

// Import routes
const authRoutes = require('./routes/auth');
const propertyRoutes = require('./routes/properties');
const paymentRoutes = require('./routes/payments');
const mpesaRoutes = require('./routes/mpesa');
const walletRoutes = require('./routes/wallet');
const creditRoutes = require('./routes/credit');
const adminRoutes = require('./routes/admin');

// Import cron jobs
const rentReminder = require('./cron/rentReminder');

const app = express();

// Middleware
app.use(helmet());
app.use(cors({
  origin: ['https://makao.co.ke', 'http://localhost:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 100,
  message: { error: 'Too many requests, please try again later.' },
});
app.use('/v1/', limiter);

// Routes
app.use('/v1/auth', authRoutes);
app.use('/v1/properties', propertyRoutes);
app.use('/v1/payments', paymentRoutes);
app.use('/v1/mpesa', mpesaRoutes);
app.use('/v1/wallet', walletRoutes);
app.use('/v1/credit', creditRoutes);
app.use('/v1/admin', adminRoutes);

// Health check
app.get('/v1/health', (req, res) => {
  res.json({
    status: 'OK',
    app: 'Makao API',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
  });
});

// Cron Jobs
// Run rent reminders daily at 8 AM EAT
cron.schedule('0 8 * * *', () => {
  rentReminder.sendReminders();
});

// Run credit score updates daily at midnight
cron.schedule('0 0 * * *', () => {
  const { updateAllCreditScores } = require('./utils/creditCalculator');
  updateAllCreditScores();
});

// Database connection
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`❌ MongoDB Error: ${error.message}`);
    process.exit(1);
  }
};

// Start server
const PORT = process.env.PORT || 5000;
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🏠 Makao Server running on port ${PORT}`);
    console.log(`📍 Environment: ${process.env.NODE_ENV}`);
  });
});

module.exports = app;