class ApiConfig {
  // Production URL — replace with your actual server
  static const String baseUrl = 'https://api.makao.co.ke/v1';
  
  // Endpoints
  static const String login = '/auth/login';
  static const String register = '/auth/register';
  static const String properties = '/properties';
  static const String propertiesByTown = '/properties/town';
  static const String propertiesByEstate = '/properties/estate';
  static const String mpesaStkPush = '/mpesa/stk-push';
  static const String mpesaCallback = '/mpesa/callback';
  static const String payments = '/payments';
  static const String wallet = '/wallet';
  static const String walletWithdraw = '/wallet/withdraw';
  static const String creditScore = '/credit';
  static const String creditLookup = '/credit/lookup';
  static const String leases = '/leases';
  static const String adminDashboard = '/admin/dashboard';

  // Kenyan Towns & Estates Data
  static const Map<String, List<String>> townsAndEstates = {
    'Nairobi': [
      'Embakasi', 'Westlands', 'Kilimani', 'Kibera', 'Eastleigh',
      'Roysambu', 'Kasarani', 'Langata', 'South B', 'South C',
      'Buruburu', 'Umoja', 'Donholm', 'Pipeline', 'Zimmerman',
      'Kahawa', 'Ruai', 'Kitengela', 'Syokimau', 'Ngong Road',
    ],
    'Mombasa': [
      'Bamburi', 'Nyali', 'Likoni', 'Shanzu', 'Mtwapa',
      'Kilifi', 'Diani', 'Tudor', 'Kongowea', 'Changamwe',
    ],
    'Nakuru': [
      'Bahati', 'Naivasha', 'Lanet', 'Njoro', 'Gilgil',
      'Menengai', 'Milimani', 'Kiamunyi', 'Freehold', 'Section 58',
    ],
    'Kisumu': [
      'Nyalenda', 'Milimani', 'Obunga', 'Manyatta', 'Kondele',
      'Nyamasaria', 'Kisat', 'Tom Mboya', 'Railways', 'Oginga Odinga',
    ],
    'Eldoret': [
      'Kapsoya', 'Langas', 'Huruma', 'Kipkorgot', 'Mailinne',
      'Pioneer', 'Kimumu', 'Kapyemit', 'Zion Mall Area', 'Kipkenyo',
    ],
    'Kisii': [
      'Nyamataro', 'Jogoo', 'Keumbu', 'Daraja Mbili', 'Nyanchwa',
      'Birongo', 'Ibeno', 'Mwembe', 'Gesusu', 'Nyakoe',
    ],
  };
}