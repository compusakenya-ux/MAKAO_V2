const Lease = require('../models/Lease');
const Payment = require('../models/Payment');
const User = require('../models/User');
const { sendRentReminder } = require('../utils/whatsappUtils');

async function sendReminders() {
  try {
    const currentDate = new Date();
    const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
    const currentYear = currentDate.getFullYear();

    // Find active leases where rent hasn't been paid this month
    const activeLeases = await Lease.find({ status: 'active' }).populate(
      'tenantId'
    );

    for (const lease of activeLeases) {
      const existingPayment = await Payment.findOne({
        tenantId: lease.tenantId._id,
        propertyId: lease.propertyId,
        paymentMonth: currentMonth,
        paymentYear: currentYear,
        status: 'completed',
      });

      if (!existingPayment) {
        const dueDate = new Date(
          currentYear,
          currentDate.getMonth(),
          lease.dueDayOfMonth
        );

        // Send reminder 3 days before and on due date
        const daysUntilDue = Math.floor(
          (dueDate - currentDate) / (1000 * 60 * 60 * 24)
        );

        if (daysUntilDue <= 3 && daysUntilDue >= -5) {
          await sendRentReminder(
            lease.tenantId.phoneNumber,
            lease.tenantId.fullName,
            lease.monthlyRent,
            dueDate.toLocaleDateString('en-KE')
          );
          console.log(`📱 Reminder sent to ${lease.tenantId.fullName}`);
        }
      }
    }

    console.log('✅ Rent reminder cron completed');
  } catch (error) {
    console.error('Reminder Cron Error:', error.message);
  }
}

module.exports = { sendReminders };