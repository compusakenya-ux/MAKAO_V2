import 'package:flutter/material.dart';
import '../../config/theme.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final _withdrawController = TextEditingController();
  final _mpesaNumberController = TextEditingController();
  bool _isWithdrawing = false;

  // Mock data
  final double _walletBalance = 45600.00;
  final double _totalEarned = 540000.00;
  final double _totalWithdrawn = 494400.00;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Wallet')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Wallet Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [MakaoTheme.primaryGreen, Color(0xFF004D2C)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: MakaoTheme.primaryGreen.withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Available Balance',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'KES ${_walletBalance.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _buildWalletStat(
                          'Total Earned', 'KES ${_totalEarned.toStringAsFixed(0)}'),
                      const SizedBox(width: 24),
                      _buildWalletStat('Withdrawn',
                          'KES ${_totalWithdrawn.toStringAsFixed(0)}'),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'ℹ️ 2% Makao commission is auto-deducted from each payment',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Withdraw Section
            const Text(
              'Withdraw to M-Pesa',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _withdrawController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Amount (KES)',
                prefixText: 'KES ',
                prefixIcon: Icon(Icons.money),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _mpesaNumberController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'M-Pesa Number',
                prefixText: '+254 ',
                prefixIcon: Icon(Icons.phone),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _isWithdrawing ? null : _withdraw,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4CAF50),
                ),
                child: _isWithdrawing
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('WITHDRAW TO M-PESA'),
              ),
            ),

            const SizedBox(height: 32),

            // Transaction History
            const Text(
              'Recent Transactions',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 12),
            _buildTransactionItem(
              'Rent - John Kamau',
              '+KES 14,700',
              'Jul 5, 2026',
              Colors.green,
              '2% fee: KES 300',
            ),
            _buildTransactionItem(
              'Rent - Mary Wanjiku',
              '+KES 24,500',
              'Jul 3, 2026',
              Colors.green,
              '2% fee: KES 500',
            ),
            _buildTransactionItem(
              'Withdrawal to 0722***',
              '-KES 20,000',
              'Jul 1, 2026',
              Colors.red,
              'To M-Pesa',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWalletStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.6),
            fontSize: 12,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildTransactionItem(
      String title, String amount, String date, Color color, String subtitle) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.1),
          child: Icon(
            amount.startsWith('+') ? Icons.arrow_downward : Icons.arrow_upward,
            color: color,
          ),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              amount,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
            Text(date, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
          ],
        ),
      ),
    );
  }

  Future<void> _withdraw() async {
    setState(() => _isWithdrawing = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) {
      setState(() => _isWithdrawing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Withdrawal initiated to M-Pesa!'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }
}