import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../config/theme.dart';
import '../../config/api_config.dart';
import '../../models/property.dart';

class AddPropertyScreen extends StatefulWidget {
  const AddPropertyScreen({super.key});

  @override
  State<AddPropertyScreen> createState() => _AddPropertyScreenState();
}

class _AddPropertyScreenState extends State<AddPropertyScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _rentController = TextEditingController();
  final _depositController = TextEditingController();

  String _selectedTown = 'Nairobi';
  String _selectedEstate = 'Embakasi';
  String _propertyType = 'Apartment';
  int _bedrooms = 1;
  int _bathrooms = 1;
  bool _isSubmitting = false;

  final List<String> _propertyTypes = [
    'Bedsitter',
    '1 Bedroom',
    '2 Bedroom',
    '3 Bedroom',
    'Apartment',
    'Maisonette',
    'Bungalow',
    'Studio',
  ];

  final List<String> _amenitiesList = [
    'WiFi',
    'Parking',
    'Water Tank',
    'Borehole',
    'Security',
    'CCTV',
    'Gym',
    'Swimming Pool',
    'Backup Generator',
    'Elevator',
    'Balcony',
    'Hot Shower',
  ];
  final Set<String> _selectedAmenities = {};

  @override
  Widget build(BuildContext context) {
    final estates = ApiConfig.townsAndEstates[_selectedTown] ?? [];

    return Scaffold(
      appBar: AppBar(title: const Text('Add Vacant Property')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Property Title
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Property Title *',
                hintText: 'e.g., Spacious 2BR in Embakasi',
                prefixIcon: Icon(Icons.title),
              ),
              validator: (v) => v!.isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 16),

            // Town & Estate
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedTown,
                    decoration: const InputDecoration(labelText: 'Town *'),
                    items: ApiConfig.townsAndEstates.keys
                        .map((t) =>
                            DropdownMenuItem(value: t, child: Text(t)))
                        .toList(),
                    onChanged: (v) {
                      setState(() {
                        _selectedTown = v!;
                        _selectedEstate =
                            ApiConfig.townsAndEstates[v]!.first;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedEstate,
                    decoration: const InputDecoration(labelText: 'Estate *'),
                    items: estates
                        .map((e) =>
                            DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedEstate = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Property Type
            DropdownButtonFormField<String>(
              value: _propertyType,
              decoration: const InputDecoration(
                labelText: 'Property Type *',
                prefixIcon: Icon(Icons.home),
              ),
              items: _propertyTypes
                  .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                  .toList(),
              onChanged: (v) => setState(() => _propertyType = v!),
            ),
            const SizedBox(height: 16),

            // Bedrooms & Bathrooms
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: _bedrooms,
                    decoration:
                        const InputDecoration(labelText: 'Bedrooms'),
                    items: List.generate(
                      5,
                      (i) => DropdownMenuItem(
                          value: i + 1, child: Text('${i + 1}')),
                    ),
                    onChanged: (v) => setState(() => _bedrooms = v!),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: _bathrooms,
                    decoration:
                        const InputDecoration(labelText: 'Bathrooms'),
                    items: List.generate(
                      4,
                      (i) => DropdownMenuItem(
                          value: i + 1, child: Text('${i + 1}')),
                    ),
                    onChanged: (v) => setState(() => _bathrooms = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Rent & Deposit
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _rentController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Monthly Rent (KES) *',
                      prefixText: 'KES ',
                      prefixIcon: Icon(Icons.money),
                    ),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _depositController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Deposit (KES)',
                      prefixText: 'KES ',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Description
            TextFormField(
              controller: _descriptionController,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Description',
                hintText: 'Describe the property...',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 16),

            // Amenities
            const Text(
              'Amenities',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _amenitiesList.map((amenity) {
                final isSelected = _selectedAmenities.contains(amenity);
                return FilterChip(
                  label: Text(amenity),
                  selected: isSelected,
                  onSelected: (selected) {
                    setState(() {
                      if (selected) {
                        _selectedAmenities.add(amenity);
                      } else {
                        _selectedAmenities.remove(amenity);
                      }
                    });
                  },
                  selectedColor: MakaoTheme.primaryGreen.withOpacity(0.2),
                  checkmarkColor: MakaoTheme.primaryGreen,
                );
              }).toList(),
            ),
            const SizedBox(height: 24),

            // Submit Button
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submitProperty,
                child: _isSubmitting
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('LIST MY PROPERTY'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submitProperty() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSubmitting = true);

    try {
      // In production: upload images, then POST to API
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Property listed successfully!'),
            backgroundColor: MakaoTheme.primaryGreen,
          ),
        );
        Navigator.pop(context);
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }
}