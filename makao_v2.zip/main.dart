import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'config/theme.dart';
import 'screens/splash_screen.dart';
import 'services/auth_service.dart';
import 'services/property_service.dart';
import 'services/payment_service.dart';
import 'services/credit_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MakaoApp());
}

class MakaoApp extends StatelessWidget {
  const MakaoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => PropertyService()),
        ChangeNotifierProvider(create: (_) => PaymentService()),
        ChangeNotifierProvider(create: (_) => CreditService()),
      ],
      child: MaterialApp(
        title: 'Makao',
        debugShowCheckedModeBanner: false,
        theme: MakaoTheme.lightTheme,
        darkTheme: MakaoTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: const SplashScreen(),
      ),
    );
  }
}