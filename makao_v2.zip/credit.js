const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');
const {
  getMyCreditScore,
  lookupTenantCredit,
} = require('../controllers/creditController');

// Tenant views own score
router.get('/my-score', protect, getMyCreditScore);

// Landlord/Admin looks up tenant
router.post(
  '/lookup',
  protect,
  roleCheck(['landlord', 'admin']),
  lookupTenantCredit
);

module.exports = router;